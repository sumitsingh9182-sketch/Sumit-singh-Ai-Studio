import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Enable JSON request body parsing
  app.use(express.json());

  // API routes can be defined here if needed
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/contact", async (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ error: "Name, email, and message are required." });
    }

    const cleanEnvValue = (val: string | undefined): string => {
      if (!val) return "";
      let s = val.trim();
      if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
        s = s.slice(1, -1);
      }
      return s.trim();
    };

    const gmailUser = cleanEnvValue(process.env.GMAIL_USER) || "sumitsingh9182@gmail.com";
    const rawAppPassword = cleanEnvValue(process.env.GMAIL_APP_PASSWORD);

    if (!rawAppPassword) {
      console.warn("\n=== MAIL TRANSMISSION SIMULATION ===");
      console.warn("GMAIL_APP_PASSWORD not set in environment. Initiating mailto fallback.");
      console.warn(`Sender Name: ${name}`);
      console.warn(`Sender Email: ${email}`);
      console.warn(`Message: ${message}`);
      console.warn("=====================================\n");
      
      return res.json({
        success: true,
        simulated: true,
        fallbackMailto: true,
        message: "No SMTP credentials set. Client fallback initiated."
      });
    }

    // Google Account App Passwords are 16 letters displayed with spaces for readability (e.g., abcd efgh ijkl mnop).
    // They must be sent to the SMTP server without any spaces.
    const cleanAppPassword = rawAppPassword.replace(/\s+/g, "");

    try {
      const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: gmailUser,
          pass: cleanAppPassword,
        },
      });

      const mailOptions = {
        from: `"Portfolio Contact Form" <${gmailUser}>`,
        to: "sumitsingh9182@gmail.com",
        replyTo: email,
        subject: `New Portfolio Brief from ${name}`,
        text: `You received a new portfolio contact form submission!

Name: ${name}
Email: ${email}

Message:
${message}
`,
      };

      await transporter.sendMail(mailOptions);
      console.log(`Email successfully dispatched from ${email} to sumitsingh9182@gmail.com`);
      
      return res.json({ success: true, message: "Your message was successfully sent!" });
    } catch (error: any) {
      console.log("Notice: SMTP server transmission is unavailable or rejected credentials. Client-side mailto fallback initiated.");
      console.log(`[Details: ${error.message}]`);
      console.log("\n=== MAIL TRANSMISSION FALLBACK QUEUED ===");
      console.log(`Sender Name: ${name}`);
      console.log(`Sender Email: ${email}`);
      console.log(`Message: ${message}`);
      console.log("=========================================\n");

      // Instead of failing and showing a raw technical error block to the client, 
      // we initiate the client-side smart mailto fallback so communication is never blocked.
      return res.json({
        success: true,
        simulated: true,
        fallbackMailto: true,
        message: "SMTP authentication failed. Initiating client-side mailto fallback.",
        details: error.message
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
