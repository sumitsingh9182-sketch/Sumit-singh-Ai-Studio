export interface Project {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string; // URL for showreel/video modal
  duration: string;
  category: string;
  tags: string[];
  client: string;
  year: string;
}

export interface AwardCaseStudy {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  category: string;
  role: string;
  image?: string;
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  period: string;
  type: string;
  bullets: string[];
}

export interface EducationItem {
  id: string;
  institution: string;
  degree: string;
  period: string;
}
