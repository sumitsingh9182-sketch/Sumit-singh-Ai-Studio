import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Stats from "./components/Stats";
import Awards from "./components/Awards";
import Pillars from "./components/Pillars";
import HowItWorks from "./components/HowItWorks";
import Brands from "./components/Brands";
import SelectedWork from "./components/SelectedWork";
import Experience from "./components/Experience";
import Skills from "./components/Skills";
import Education from "./components/Education";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import VideoModal from "./components/VideoModal";
import AllVideos from "./components/AllVideos";
import EmailModal from "./components/EmailModal";
import { HERO_DATA } from "./data";
import { ArrowUp, MessageCircle, Mail } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

function MainApp() {
  const [view, setView] = useState<"home" | "all-videos">(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get("tab");
    const validSlugs = [
      "all",
      "realistic-corporate",
      "animated-corporate",
      "talking-heads",
      "map-animation",
      "long-form",
      "short-form",
      "ui-animation"
    ];
    if (tabParam && validSlugs.includes(tabParam)) {
      return "all-videos";
    }
    return "home";
  });
  const [modalOpen, setModalOpen] = useState(false);
  const [activeVideoUrl, setActiveVideoUrl] = useState("");
  const [activeVideoTitle, setActiveVideoTitle] = useState("");
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [emailModalOpen, setEmailModalOpen] = useState(false);

  // Sync state when browser navigation occurs (popstate)
  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get("tab");
      const validSlugs = [
        "all",
        "realistic-corporate",
        "animated-corporate",
        "talking-heads",
        "map-animation",
        "long-form",
        "short-form",
        "ui-animation"
      ];
      if (tabParam && validSlugs.includes(tabParam)) {
        setView("all-videos");
      } else {
        setView("home");
      }
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view]);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleWatchShowreel = () => {
    setView("all-videos");
    window.history.pushState({ tab: "all" }, "", "?tab=all");
  };

  const handlePlayProject = (videoUrl: string, title: string) => {
    setActiveVideoUrl(videoUrl);
    setActiveVideoTitle(title);
    setModalOpen(true);
  };

  const handleContactClick = () => {
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      const headerOffset = 85;
      const elementPosition = contactSection.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const handleNavigate = (href: string) => {
    if (view !== "home") {
      setView("home");
      setTimeout(() => {
        const targetElement = document.querySelector(href);
        if (targetElement) {
          const headerOffset = 80;
          const elementPosition = targetElement.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
          });
        }
      }, 100);
    } else {
      const targetElement = document.querySelector(href);
      if (targetElement) {
        const headerOffset = 80;
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    }
  };

  return (
    <div id="app-viewport" className="min-h-screen bg-[var(--color-warm-bg)] text-[var(--color-body-text)] flex flex-col justify-between selection:bg-[#FF8F33]/20 selection:text-[#FF8F33] relative">
      
      {/* Absolute top background noise & subtle gradients */}
      <div className="absolute top-0 left-0 right-0 h-[800px] bg-gradient-to-b from-[#1C1512]/15 via-transparent to-transparent pointer-events-none" />
      
      {/* Navigation Header */}
      <Header 
        onContactClick={handleContactClick} 
        currentView={view} 
        onNavigate={handleNavigate} 
      />

      {/* Main Body Stage */}
      <main className="flex-grow">
        {view === "home" ? (
          <>
            {/* Hero Section */}
            <Hero
              onWatchShowreel={handleWatchShowreel}
              onContactClick={handleContactClick}
            />

            {/* Horizontal Metrics Strip */}
            <Stats />

            {/* Awards & Recognition Section */}
            <Awards />

            {/* Pillars / Workflow Pipeline */}
            <Pillars />

            {/* How It Works Workflow Section */}
            <HowItWorks />

            {/* Grid of trusted brands */}
            <Brands />

            {/* Featured Video Project Cards */}
            <SelectedWork 
              onPlayProject={handlePlayProject} 
              onViewAllVideos={() => {
                setView("all-videos");
                window.history.pushState({ tab: "all" }, "", "?tab=all");
              }} 
            />

            {/* Experience Section */}
            <Experience />

            {/* Skills Mapping Card Bento */}
            <Skills />

            {/* Academic Details Section */}
            <Education />

            {/* Contact form & Availability Block */}
            <Contact onEmailClick={() => setEmailModalOpen(true)} />
          </>
        ) : (
          <AllVideos 
            onPlayProject={handlePlayProject} 
            onBackHome={() => {
              setView("home");
              window.history.pushState(null, "", window.location.pathname);
            }} 
          />
        )}
      </main>

      {/* Footer copyright */}
      <Footer />

      {/* Interactive Floating Screenplay Player */}
      <VideoModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        videoUrl={activeVideoUrl}
        title={activeVideoTitle}
      />

      {/* Interactive Webmail & Copy Email Helper Modal */}
      <EmailModal
        isOpen={emailModalOpen}
        onClose={() => setEmailModalOpen(false)}
        emailAddress="sumitsingh9182@gmail.com"
      />

      {/* Floating Direct Contact Actions (WhatsApp + Email) */}
      <div className="fixed bottom-6 left-6 md:bottom-8 md:left-8 z-40 flex flex-col gap-2.5 items-start">
        {/* Floating WhatsApp Action Button */}
        <motion.a
          id="floating-whatsapp-btn"
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.8 }}
          href="https://wa.me/918210458586"
          target="_blank"
          rel="noopener noreferrer"
          className="py-2.5 px-4 rounded-full bg-[#14100E] hover:bg-emerald-600 border border-emerald-500/30 text-[#FF8F33] hover:text-stone-950 shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer flex items-center gap-2 group"
          title="Chat on WhatsApp"
          aria-label="Chat on WhatsApp"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <MessageCircle className="w-3.5 h-3.5 text-emerald-400 group-hover:text-stone-950 transition-colors" />
          <span className="font-sans font-bold text-[9px] tracking-wider uppercase text-stone-300 group-hover:text-stone-950 transition-colors inline-block">
            Chat 24/7
          </span>
        </motion.a>

        {/* Floating Email Action Button */}
        <motion.button
          id="floating-email-btn"
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.9 }}
          onClick={() => setEmailModalOpen(true)}
          className="py-2.5 px-4 rounded-full bg-[#14100E] hover:bg-[#FF8F33] border border-[#FF8F33]/30 text-[#FF8F33] hover:text-stone-950 shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer flex items-center gap-2 group"
          title="Send an Email"
          aria-label="Send an Email"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF8F33]/60 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#FF8F33]"></span>
          </span>
          <Mail className="w-3.5 h-3.5 text-[#FF8F33] group-hover:text-stone-950 transition-colors" />
          <span className="font-sans font-bold text-[9px] tracking-wider uppercase text-stone-300 group-hover:text-stone-950 transition-colors inline-block">
            Email Me
          </span>
        </motion.button>
      </div>

      {/* Scroll to Top Floating Action Button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            id="scroll-to-top-btn"
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 10 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="fixed bottom-6 right-6 md:bottom-8 md:right-8 p-3.5 rounded-full bg-[#1C1512] border border-stone-850 text-[#FF8F33] hover:text-[#E5A463] hover:border-[#FF8F33]/30 shadow-2xl hover:scale-110 active:scale-95 transition-all duration-250 cursor-pointer z-40 flex items-center justify-center group"
            title="Scroll to Top"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5 transition-transform duration-300 group-hover:-translate-y-0.5" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  return <MainApp />;
}
