import React, { useState, useEffect } from "react";
import { 
  ArrowLeft, 
  Play, 
  MonitorPlay,
  LayoutGrid,
  Briefcase,
  Sparkles,
  User,
  Map,
  Clock,
  Smartphone,
  Video
} from "lucide-react";
import { PROJECTS_DATA } from "../data";
import { Project } from "../types";
import ScrollReveal from "./ScrollReveal";

interface AllVideosProps {
  onPlayProject: (videoUrl: string, title: string) => void;
  onBackHome: () => void;
}

const categoriesList = [
  { id: "all", label: "All Clips" },
  { id: "Realistic Corporate\nStyle Ai Videos", label: "Realistic Corporate\nStyle AI Videos" },
  { id: "Animated Corporate\nStyle Ai Videos", label: "Animated Corporate\nStyle AI Videos" },
  { id: "Talking heads style", label: "Talking Heads Style" },
  { id: "Map Animation", label: "Map Animation" },
  { id: "Long Form Videos", label: "Long Form Videos" },
  { id: "Short Form Videos", label: "Short Form Videos" },
  { id: "UI Animation Videos", label: "UI Animation Videos" },
];

const slugToCatId: Record<string, string> = {
  "all": "all",
  "realistic-corporate": "Realistic Corporate\nStyle Ai Videos",
  "animated-corporate": "Animated Corporate\nStyle Ai Videos",
  "talking-heads": "Talking heads style",
  "map-animation": "Map Animation",
  "long-form": "Long Form Videos",
  "short-form": "Short Form Videos",
  "ui-animation": "UI Animation Videos"
};

const catIdToSlug: Record<string, string> = {
  "all": "all",
  "Realistic Corporate\nStyle Ai Videos": "realistic-corporate",
  "Animated Corporate\nStyle Ai Videos": "animated-corporate",
  "Talking heads style": "talking-heads",
  "Map Animation": "map-animation",
  "Long Form Videos": "long-form",
  "Short Form Videos": "short-form",
  "UI Animation Videos": "ui-animation"
};

const isVerticalCategory = (categoryName: string) => {
  const norm = categoryName.toLowerCase();
  return norm.includes("talking heads") || norm.includes("map animation") || norm.includes("short form");
};

const getCategoryIcon = (catId: string, className = "w-4 h-4") => {
  switch (catId) {
    case "all":
      return <LayoutGrid className={className} />;
    case "Realistic Corporate\nStyle Ai Videos":
      return <Briefcase className={className} />;
    case "Animated Corporate\nStyle Ai Videos":
      return <Sparkles className={className} />;
    case "Talking heads style":
      return <User className={className} />;
    case "Map Animation":
      return <Map className={className} />;
    case "Long Form Videos":
      return <Clock className={className} />;
    case "Short Form Videos":
      return <Smartphone className={className} />;
    case "UI Animation Videos":
      return <MonitorPlay className={className} />;
    default:
      return <Video className={className} />;
  }
};

const renderTextWithBreaks = (text: string) => {
  return text.split("\n").map((line, idx) => (
    <React.Fragment key={idx}>
      {line}
      {idx < text.split("\n").length - 1 && <br />}
    </React.Fragment>
  ));
};

export default function AllVideos({ onPlayProject, onBackHome }: AllVideosProps) {
  const [activeTab, setActiveTab] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get("tab");
    if (tabParam && slugToCatId[tabParam]) {
      return slugToCatId[tabParam];
    }
    return "all";
  });

  // Synchronize state when the URL changes (e.g. Back/Forward navigation)
  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get("tab");
      if (tabParam && slugToCatId[tabParam]) {
        setActiveTab(slugToCatId[tabParam]);
      } else {
        setActiveTab("all");
      }
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const handleTabChange = (catId: string) => {
    setActiveTab(catId);
    const slug = catIdToSlug[catId] || "all";
    const newUrl = `${window.location.pathname}?tab=${slug}`;
    window.history.pushState({ tab: slug }, "", newUrl);
  };

  const totalCount = PROJECTS_DATA.length;

  const getCategoryCount = (catId: string) => {
    if (catId === "all") return totalCount;
    return PROJECTS_DATA.filter((p) => p.category === catId).length;
  };

  const activeCategories = categoriesList.filter((cat) => {
    if (cat.id === "all") return false;
    if (activeTab === "all") return true;
    return cat.id === activeTab;
  });

  return (
    <div id="all-videos-gallery" className="py-24 md:py-32 relative min-h-screen bg-[#0C0908]">
      {/* Background radial accent glow */}
      <div className="absolute top-1/6 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-[#FF8F33]/5 blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Back navigation and Page Title */}
        <div className="mb-10">
          <ScrollReveal direction="up">
            <button
              id="back-to-home-btn"
              onClick={onBackHome}
              className="flex items-center gap-2 text-xs font-mono text-stone-400 hover:text-[#FF8F33] uppercase tracking-wider font-semibold group mb-6 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              Go back home
            </button>
            
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-4">
              <div>
                <span className="font-mono text-[10px] text-[#FF8F33] tracking-[0.25em] font-semibold block mb-2 uppercase">
                  RECRUITER & PARTNER SHOWCASE
                </span>
                <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-normal text-stone-100 tracking-tight leading-[1.05]">
                  The <span className="italic text-[#E5A463] font-serif">Cinematic</span> Vault
                </h1>
              </div>
            </div>
            <p className="font-sans text-sm md:text-base text-stone-400 max-w-2xl leading-relaxed">
              Explore my full spectrum of AI production work. Click the highlighted filter buttons below to jump directly to specific styles of interest.
            </p>
          </ScrollReveal>
        </div>

        {/* Dynamic Nested Tab Filter Pills */}
        <ScrollReveal direction="up" delay={0.05}>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-16 pb-8 border-b border-stone-900">
            {categoriesList.map((tab) => {
              const isActive = activeTab === tab.id;
              const hasNewline = tab.label.includes("\n");
              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`px-5 py-4 rounded-xl font-sans text-xs sm:text-[13px] font-bold tracking-wide uppercase transition-all duration-300 relative flex items-center justify-between gap-3.5 cursor-pointer select-none text-left border ${
                    isActive
                      ? "text-[#0C0908] bg-[#FF8F33] border-[#FF8F33] shadow-lg shadow-[#FF8F33]/25 scale-[1.02] z-20"
                      : "text-stone-100 hover:text-white bg-[#14100E] hover:bg-[#1C1715] border-stone-800 hover:border-[#FF8F33]/40"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`transition-colors shrink-0 ${isActive ? "text-[#0C0908]" : "text-[#FF8F33]"}`}>
                      {getCategoryIcon(tab.id, "w-4.5 h-4.5")}
                    </div>
                    <span className={`${hasNewline ? "leading-[1.25] py-0.5" : "leading-none"}`}>
                      {renderTextWithBreaks(tab.label)}
                    </span>
                  </div>
                  <span className={`text-[10px] px-2.5 py-0.5 rounded-full transition-colors flex items-center justify-center h-5 shrink-0 font-extrabold ${
                    isActive
                      ? "bg-[#0C0908]/15 text-[#0C0908]"
                      : "bg-stone-800 text-stone-300"
                  }`}>
                    {getCategoryCount(tab.id)}
                  </span>
                </button>
              );
            })}
          </div>
        </ScrollReveal>

        {/* Dynamic Categorized Sections */}
        {activeCategories.map((cat, catIdx) => {
          const categoryVideos = PROJECTS_DATA.filter((p) => p.category === cat.id);
          if (categoryVideos.length === 0) return null;
          
          const isVertical = isVerticalCategory(cat.id);

          return (
            <div key={cat.id} className="mb-24">
              {/* Category Header */}
              <ScrollReveal direction="up" delay={catIdx * 0.05}>
                <div className="flex items-baseline justify-between mb-8 pb-3 border-b border-stone-900">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs bg-[#FF8F33]/10 text-[#FF8F33] px-3 py-1 rounded-full font-bold">
                      {categoryVideos.length} {isVertical ? "shorts" : "pieces"}
                    </span>
                    <h2 className="font-serif text-2xl md:text-3xl font-medium text-stone-100 tracking-tight leading-tight text-left">
                      {renderTextWithBreaks(cat.id)}
                    </h2>
                  </div>
                  <span className="hidden sm:inline font-mono text-[10px] text-stone-500 tracking-wider uppercase">
                    {isVertical ? "9:16 VERTICAL ASPECT" : "16:9 CINEMATIC RATIO"}
                  </span>
                </div>
              </ScrollReveal>

              {/* Grid of Videos under this category */}
              <ScrollReveal direction="up" delay={catIdx * 0.05 + 0.05}>
                <div className={isVertical 
                  ? "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto" 
                  : "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8"
                }>
                  {categoryVideos.map((project: Project) => (
                    <div
                      key={project.id}
                      id={`vault-card-${project.id}`}
                      className="group flex flex-col justify-between items-start text-left rounded-2xl border border-stone-900 bg-[#14100E] p-4 transition-all duration-500 hover:border-stone-800 glow-card w-full"
                    >
                      <div className="w-full">
                        {/* Image Container with Hover Play button */}
                        <div
                          onClick={() => onPlayProject(project.videoUrl, project.title)}
                          className={`w-full rounded-xl overflow-hidden bg-stone-950 relative cursor-pointer ${
                            isVertical ? "aspect-[9/16]" : "aspect-[16/9]"
                          }`}
                        >
                          <img
                            src={project.thumbnail}
                            alt={project.title}
                            className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 ease-out"
                            referrerPolicy="no-referrer"
                          />
                          {/* Hover visual overlays */}
                          <div className="absolute inset-0 bg-[#0C0908]/20 group-hover:bg-[#0C0908]/40 transition-colors duration-300" />
                          
                          {/* Overlay Play Button */}
                          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <div className="w-12 h-12 rounded-full bg-[#FF8F33] text-[#0C0908] flex items-center justify-center shadow-xl shadow-black/30 scale-90 group-hover:scale-100 transition-all duration-300">
                              <Play className="w-5 h-5 fill-[#0C0908] translate-x-[1px]" />
                            </div>
                          </div>

                          {/* Corner indicator */}
                          <div className="absolute top-3 right-3 bg-[#0C0908]/80 backdrop-blur-md px-2.5 py-1 rounded-full text-[9px] font-mono text-[#E5A463] font-medium flex items-center gap-1">
                            <MonitorPlay className="w-3 h-3" />
                            {project.duration}
                          </div>
                        </div>

                        {/* Content */}
                        <div className="pt-5 px-1">
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <span className="font-mono text-[9px] text-[#FF8F33] tracking-widest uppercase">
                              {project.client}
                            </span>
                            <span className="font-mono text-[9px] text-stone-500">
                              {project.year}
                            </span>
                          </div>
                          <h3 className="font-serif text-base sm:text-lg text-stone-100 font-semibold tracking-tight mb-2 group-hover:text-[#FF8F33] transition-colors line-clamp-1">
                            {project.title}
                          </h3>
                          <p className="font-sans text-xs text-stone-400 leading-relaxed mb-4 min-h-[50px] line-clamp-2">
                            {project.description}
                          </p>
                        </div>
                      </div>

                      {/* Tags */}
                      <div className="w-full px-1">
                        <div className="flex flex-wrap gap-1.5">
                          {project.tags.map((tag) => (
                            <span
                              key={tag}
                              className="text-[9px] font-mono font-bold tracking-wider px-2.5 py-1 rounded-md bg-stone-900 border border-stone-850/60 text-stone-400 uppercase"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollReveal>
            </div>
          );
        })}

        {/* Back Home centered trigger footer */}
        <ScrollReveal direction="up" delay={0.1}>
          <div className="flex flex-col items-center justify-center mt-20 pt-10 border-t border-stone-900">
            <p className="text-xs text-stone-500 font-mono mb-4">Want to talk about a custom video project or collaboration?</p>
            <button
              id="back-home-bottom-trigger"
              onClick={onBackHome}
              className="px-6 py-3 rounded-full bg-[#FF8F33] text-[#0C0908] hover:bg-[#FF8F33]/90 font-sans font-bold text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 shadow-lg shadow-[#FF8F33]/10"
            >
              Return to main showcase
            </button>
          </div>
        </ScrollReveal>

      </div>
    </div>
  );
}
