import React from "react";
import { motion } from "motion/react";
import ScrollReveal from "./ScrollReveal";

const STEPS = [
  {
    id: "01",
    title: "Brief",
    description: "You share the goal, brand and audience. We map the angle."
  },
  {
    id: "02",
    title: "Concept",
    description: "We pitch hooks, scripts and visual directions — pick your favorites."
  },
  {
    id: "03",
    title: "Produce",
    description: "AI production + human direction. Fast rounds, real polish."
  },
  {
    id: "04",
    title: "Launch",
    description: "Delivery in every format, ready to ship and scale."
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-16 md:py-24 relative overflow-hidden">
      {/* Background ambient subtle glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-[#FF8F33]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        <ScrollReveal direction="up">
          <div className="text-left mb-12">
            <span className="inline-block px-3.5 py-1 bg-[#1C1512] text-[#FF8F33] rounded-full border border-[#FF8F33]/20 text-[10px] font-mono font-bold tracking-wider uppercase mb-4 shadow-md">
              How It Works
            </span>
            <h2 id="how-it-works-heading" className="font-serif text-4xl sm:text-5xl md:text-6xl font-normal text-stone-100 tracking-tight leading-[1.05]">
              From brief to <span className="italic text-[#FF8F33] font-serif">banger.</span>
            </h2>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {STEPS.map((step, idx) => (
            <div key={step.id}>
              <ScrollReveal direction="up" delay={idx * 0.1}>
                <div
                  id={`how-it-works-card-${step.id}`}
                  className="group p-6 md:p-8 rounded-2xl border-2 border-[#231B17] bg-[#14100E] shadow-[4px_4px_0px_0px_#1C1512] hover:shadow-[6px_6px_0px_0px_rgba(255,143,51,0.25)] hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between items-start text-left min-h-[220px] cursor-default"
                >
                  <div className="w-full flex flex-col justify-between h-full">
                    <div>
                      <span className="font-serif text-4xl md:text-5xl font-semibold text-stone-600/80 group-hover:text-[#FF8F33] transition-colors duration-300 block mb-5">
                        {step.id}
                      </span>
                      <h3 className="font-sans text-xl font-bold text-stone-100 mb-2.5 group-hover:text-[#E5A463] transition-colors duration-300">
                        {step.title}
                      </h3>
                      <p className="font-sans text-xs md:text-sm text-stone-400 leading-relaxed group-hover:text-stone-300 transition-colors duration-300">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
