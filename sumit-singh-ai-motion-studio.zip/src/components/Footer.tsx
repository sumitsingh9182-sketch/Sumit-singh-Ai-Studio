import React from "react";
import { Mail, Linkedin, Heart, MessageCircle } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-8 border-t border-stone-900/60 bg-stone-950/20">
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* Left: Copyright */}
        <div className="text-left">
          <p className="font-sans text-xs md:text-sm text-stone-500 font-medium">
            © 2026 Sumit Singh. All Rights Reserved.
          </p>
        </div>

        {/* Center: Small Social Icons */}
        <div className="flex items-center gap-3">
          <a
            id="footer-social-whatsapp"
            href="https://wa.me/918210458586"
            target="_blank"
            rel="noopener noreferrer"
            className="w-8 h-8 rounded-full border border-stone-850 hover:border-emerald-500 text-stone-500 hover:text-emerald-500 flex items-center justify-center transition-all duration-300"
            aria-label="WhatsApp"
          >
            <MessageCircle className="w-4 h-4" />
          </a>
          <a
            id="footer-social-email"
            href="mailto:sumitsingh9182@gmail.com"
            className="w-8 h-8 rounded-full border border-stone-850 hover:border-[#FF8F33] text-stone-500 hover:text-[#FF8F33] flex items-center justify-center transition-all duration-300"
            aria-label="Email"
          >
            <Mail className="w-4 h-4" />
          </a>
          <a
            id="footer-social-linkedin"
            href="https://www.linkedin.com/in/sumit-singh-08b702370/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-8 h-8 rounded-full border border-stone-850 hover:border-[#E5A463] text-stone-500 hover:text-[#E5A463] flex items-center justify-center transition-all duration-300"
            aria-label="LinkedIn"
          >
            <Linkedin className="w-4 h-4" />
          </a>
        </div>

        {/* Right: Credits */}
        <div className="text-right flex items-center gap-1.5 font-sans text-xs md:text-sm text-stone-500 font-medium">
          <span>Designed & animated in New Delhi, Delhi, India.</span>
        </div>

      </div>
    </footer>
  );
}
