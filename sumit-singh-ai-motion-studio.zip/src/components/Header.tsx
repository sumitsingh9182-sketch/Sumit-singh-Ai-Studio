import React, { useState, useEffect } from "react";
import { Menu, X, ArrowUpRight, Sun, Moon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { HERO_DATA } from "../data";

interface HeaderProps {
  onContactClick: () => void;
  currentView?: "home" | "all-videos";
  onNavigate?: (href: string) => void;
}

export default function Header({ onContactClick, currentView = "home", onNavigate }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") as "dark" | "light" | null;
    const initialTheme = savedTheme || "dark";
    setTheme(initialTheme);
    if (initialTheme === "light") {
      document.documentElement.classList.add("light-mode");
    } else {
      document.documentElement.classList.remove("light-mode");
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    if (newTheme === "light") {
      document.documentElement.classList.add("light-mode");
    } else {
      document.documentElement.classList.remove("light-mode");
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Home", href: "#home" },
    { name: "Work", href: "#work" },
    { name: "Awards", href: "#awards" },
    { name: "Experience", href: "#experience" },
    { name: "Skills", href: "#skills" },
    { name: "Contact", href: "#contact" }
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    if (onNavigate) {
      onNavigate(href);
    } else {
      const targetElement = document.querySelector(href);
      if (targetElement) {
        const headerOffset = 80;
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    }
  };

  return (
    <header
      id="site-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#0C0908]/85 backdrop-blur-md border-b border-white/5 py-4 shadow-xl shadow-black/10"
          : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Logo */}
        <a
          id="header-logo"
          href="#home"
          onClick={(e) => handleNavClick(e, "#home")}
          className="flex items-center gap-3 group"
        >
          <div className="w-9 h-9 rounded bg-[#FF8F33] flex items-center justify-center font-serif text-lg font-bold text-[#0C0908] shadow-lg shadow-[#FF8F33]/20 group-hover:scale-105 transition-transform duration-300">
            S
          </div>
          <span className="font-sans font-semibold tracking-wider text-sm md:text-base text-stone-100 group-hover:text-[#FF8F33] transition-colors duration-300 uppercase">
            Sumit Singh
          </span>
        </a>

        {/* Desktop Navigation */}
        <nav id="desktop-nav" className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.name}
              id={`nav-item-${item.name.toLowerCase()}`}
              href={item.href}
              onClick={(e) => handleNavClick(e, item.href)}
              className="text-stone-400 hover:text-stone-100 font-sans text-sm font-medium tracking-wide transition-colors duration-200 relative py-1"
            >
              {item.name}
            </a>
          ))}
        </nav>

        {/* Desktop Buttons */}
        <div className="hidden md:flex items-center gap-3">
          <button
            id="theme-toggle-btn"
            onClick={toggleTheme}
            className="p-2 rounded-full border border-stone-800 hover:border-stone-600 hover:bg-stone-900/30 text-stone-300 hover:text-stone-100 transition-all duration-200 cursor-pointer flex items-center justify-center relative group"
            title={theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode"}
            aria-label="Toggle theme"
          >
            {theme === "dark" ? (
              <Sun className="w-4 h-4 text-[#FF8F33] transition-transform duration-300 group-hover:rotate-45" />
            ) : (
              <Moon className="w-4 h-4 text-[#B46F2E] transition-transform duration-300 group-hover:-rotate-12" />
            )}
          </button>

          <a
            id="header-resume-btn"
            href={HERO_DATA.resumeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-full border border-stone-800 hover:border-stone-600 hover:bg-stone-900/30 text-stone-300 font-sans font-medium text-xs uppercase tracking-wider hover:text-stone-100 transition-all duration-200 cursor-pointer flex items-center gap-1 group"
          >
            Resume
            <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 text-[#E5A463] transition-transform duration-200" />
          </a>
          <button
            id="header-hire-me-btn"
            onClick={onContactClick}
            className="px-5 py-2 rounded-full bg-gradient-to-r from-[#FF8F33] to-[#E5A463] text-[#0C0908] font-sans font-semibold text-xs uppercase tracking-wider hover:opacity-90 active:scale-95 transition-all duration-200 cursor-pointer flex items-center gap-1 group shadow-lg shadow-[#FF8F33]/10"
          >
            Hire Me
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200" />
          </button>
        </div>

        {/* Mobile menu trigger and theme toggle */}
        <div className="flex items-center gap-1 md:hidden">
          <button
            id="theme-toggle-mobile"
            onClick={toggleTheme}
            className="p-2 text-stone-400 hover:text-stone-100 hover:bg-white/5 rounded-full transition-colors cursor-pointer"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? (
              <Sun className="w-5 h-5 text-[#FF8F33]" />
            ) : (
              <Moon className="w-5 h-5 text-[#B46F2E]" />
            )}
          </button>
          
          <button
            id="mobile-menu-trigger"
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 text-stone-400 hover:text-stone-100 hover:bg-white/5 rounded-full transition-colors"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-nav-panel"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="md:hidden bg-[#0C0908]/95 backdrop-blur-lg border-b border-white/5 absolute top-full left-0 right-0 overflow-hidden"
          >
            <div className="px-6 py-6 flex flex-col gap-5">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  id={`mobile-nav-item-${item.name.toLowerCase()}`}
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  className="text-stone-300 hover:text-[#FF8F33] font-sans text-base font-medium tracking-wide py-2 border-b border-white/5 last:border-0"
                >
                  {item.name}
                </a>
              ))}
              <a
                id="mobile-nav-resume-btn"
                href={HERO_DATA.resumeUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsOpen(false)}
                className="w-full mt-2 py-3 rounded-xl border border-stone-800 text-stone-300 hover:text-stone-100 font-sans font-semibold text-sm uppercase tracking-wider text-center block"
              >
                Resume
              </a>
              <button
                id="mobile-nav-hire-me-btn"
                onClick={() => {
                  setIsOpen(false);
                  onContactClick();
                }}
                className="w-full mt-1 py-3 rounded-xl bg-[#FF8F33] text-[#0C0908] font-sans font-bold text-sm uppercase tracking-wider text-center cursor-pointer"
              >
                Hire Me
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
