import React, { useRef, useState, useEffect } from "react";
import { X, Play, Pause, Volume2, VolumeX, RotateCcw, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string;
  title: string;
}

function getYouTubeEmbedUrl(url: string): string | null {
  if (!url) return null;
  const cleanUrl = url.trim();
  let videoId = "";
  if (cleanUrl.includes("youtu.be/")) {
    videoId = cleanUrl.split("youtu.be/")[1]?.split(/[?#]/)[0];
  } else if (cleanUrl.includes("youtube.com/shorts/")) {
    videoId = cleanUrl.split("youtube.com/shorts/")[1]?.split(/[?#]/)[0];
  } else if (cleanUrl.includes("youtube.com/watch")) {
    const parts = cleanUrl.split("?")[1];
    if (parts) {
      const urlParams = new URLSearchParams(parts);
      videoId = urlParams.get("v") || "";
    }
  } else if (cleanUrl.includes("youtube.com/embed/")) {
    videoId = cleanUrl.split("youtube.com/embed/")[1]?.split(/[?#]/)[0];
  }
  
  if (videoId) {
    return `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&showinfo=0&modestbranding=1`;
  }
  return null;
}

export default function VideoModal({ isOpen, onClose, videoUrl, title }: VideoModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const ytEmbedUrl = getYouTubeEmbedUrl(videoUrl);
  const isYouTube = !!ytEmbedUrl;
  const isVertical = videoUrl.includes("shorts") || videoUrl.includes("vertical") || title.toLowerCase().includes("telly") || title.toLowerCase().includes("scaling") || title.toLowerCase().includes("pipeline");

  // Reset player state when changing videos
  useEffect(() => {
    if (isOpen) {
      setIsLoading(true);
      setIsPlaying(true);
      if (!isYouTube && videoRef.current) {
        videoRef.current.load();
      } else {
        setIsLoading(false);
      }
    }
  }, [videoUrl, isOpen, isYouTube]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play().catch(() => {});
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration || 0);
      setIsLoading(false);
    }
  };

  const handleVideoEnded = () => {
    setIsPlaying(false);
  };

  const restartVideo = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (videoRef.current && duration > 0) {
      const rect = e.currentTarget.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const width = rect.width;
      const newTime = (clickX / width) * duration;
      videoRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          id="video-player-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#0C0908]/95 backdrop-blur-md p-4 sm:p-6"
        >
          {/* Close click blocker background */}
          <div className="absolute inset-0 cursor-pointer" onClick={onClose} />

          {/* Modal Container */}
          <motion.div
            id="video-player-container"
            initial={{ scale: 0.95, y: 15 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: 15 }}
            transition={{ type: "spring", damping: 25, stiffness: 180 }}
            className={`relative bg-stone-950 border border-stone-900 rounded-2xl overflow-hidden shadow-2xl shadow-black z-10 w-full ${
              isVertical ? "max-w-[360px]" : "max-w-4xl"
            }`}
          >
            {/* Header: Title and Close button */}
            <div className="px-6 py-4 border-b border-stone-900 flex items-center justify-between bg-stone-950 text-left">
              <div className="pr-4 overflow-hidden">
                <span className="text-[10px] font-mono text-[#FF8F33] uppercase tracking-wider font-semibold">
                  Active Screening
                </span>
                <h3 className="font-serif text-base text-stone-100 font-medium leading-tight mt-1 truncate">
                  {title}
                </h3>
              </div>
              
              <button
                id="btn-close-player"
                onClick={onClose}
                className="p-2 text-stone-400 hover:text-stone-100 bg-stone-900/60 hover:bg-stone-900 rounded-full transition-colors cursor-pointer flex-shrink-0"
                aria-label="Close player"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Video Stage */}
            <div className={`relative w-full bg-black group/controls ${
              isVertical ? "aspect-[9/16]" : "aspect-[16/9]"
            }`}>
              {/* Spinning Loader */}
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-stone-950/80 z-20">
                  <div className="flex flex-col items-center gap-2">
                    <Loader2 className="w-8 h-8 text-[#FF8F33] animate-spin" />
                    <span className="font-mono text-xs text-stone-400">Loading Pipeline stream...</span>
                  </div>
                </div>
              )}

              {/* The Video Element / YouTube iframe */}
              {isYouTube ? (
                <iframe
                  src={ytEmbedUrl || ""}
                  title={title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  className="w-full h-full object-cover"
                />
              ) : (
                <>
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    autoPlay
                    playsInline
                    muted={isMuted}
                    onTimeUpdate={handleTimeUpdate}
                    onLoadedMetadata={handleLoadedMetadata}
                    onEnded={handleVideoEnded}
                    onClick={togglePlay}
                    className="w-full h-full object-contain cursor-pointer"
                  />

                  {/* Custom Controller Overlay Bar (only for HTML5 native video) */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col gap-3 transition-opacity duration-300 opacity-100 sm:opacity-0 sm:group-hover/controls:opacity-100">
                    
                    {/* Progress bar scrubbable */}
                    <div
                      className="w-full h-1.5 bg-stone-800 rounded-full overflow-hidden cursor-pointer relative hover:h-2 transition-all"
                      onClick={handleProgressBarClick}
                    >
                      <div
                        className="bg-[#FF8F33] h-full rounded-full transition-all duration-100"
                        style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                      />
                    </div>

                    {/* Left/Right actions bar */}
                    <div className="flex items-center justify-between text-stone-300">
                      <div className="flex items-center gap-4">
                        {/* Play/Pause toggle */}
                        <button
                          onClick={togglePlay}
                          className="hover:text-[#FF8F33] transition-colors cursor-pointer"
                          aria-label={isPlaying ? "Pause" : "Play"}
                        >
                          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                        </button>

                        {/* Restart */}
                        <button
                          onClick={restartVideo}
                          className="hover:text-[#FF8F33] transition-colors cursor-pointer"
                          aria-label="Restart"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>

                        {/* Time counters */}
                        <span className="font-mono text-xs text-stone-400">
                          {formatTime(currentTime)} / {formatTime(duration)}
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        {/* Volume Mute Toggle */}
                        <button
                          onClick={toggleMute}
                          className="hover:text-[#FF8F33] transition-colors cursor-pointer"
                          aria-label={isMuted ? "Unmute" : "Mute"}
                        >
                          {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                  </div>
                </>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
