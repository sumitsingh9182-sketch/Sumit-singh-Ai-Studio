import React from "react";
import { Mail, Linkedin, MapPin, Phone, MessageCircle, Calendar, ArrowRight, Clock, Video } from "lucide-react";
import { motion } from "motion/react";
import ScrollReveal from "./ScrollReveal";

interface ContactProps {
  onEmailClick?: () => void;
}

export default function Contact({ onEmailClick }: ContactProps) {
  return (
    <section id="contact" className="py-16 md:py-24 relative overflow-hidden">
      {/* Background glow behind form */}
      <div className="absolute right-0 bottom-0 w-[400px] h-[400px] bg-[#FF8F33]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          
          {/* Left Column: Open for Work info */}
          <ScrollReveal direction="up" duration={0.8} className="h-full">
            <div
              id="contact-info-card"
              className="p-8 md:p-12 rounded-3xl border border-stone-900 bg-[#14100E] hover:border-[#FF8F33]/10 transition-colors duration-500 flex flex-col justify-between text-left h-full"
            >
              <div>
                <span className="flex items-center gap-1.5 bg-[#FF8F33]/10 px-3 py-1 rounded-full text-[10px] text-[#FF8F33] font-mono font-bold uppercase tracking-wider w-fit mb-6">
                  <span className="w-1.5 h-1.5 bg-[#FF8F33] rounded-full animate-ping" />
                  OPEN FOR WORK
                </span>

                <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-stone-100 tracking-tight leading-[1.05]">
                  Motion systems for <span className="italic text-[#FF8F33]">product, learning, and brand teams.</span>
                </h2>

                <p className="font-sans text-sm md:text-base text-stone-400 leading-relaxed mt-6">
                  Remote-first across India, UAE, US and EU. Available for full project ownership, fractional motion-lead retainers, and AI video pipelines.
                </p>
              </div>

              {/* Social channels / Connect buttons */}
              <div className="mt-12 space-y-3">
                <p className="font-mono text-[10px] text-stone-500 uppercase tracking-widest block mb-4">
                  DIRECT CHANNELS
                </p>
                
                <div className="flex flex-wrap gap-2.5">
                  <a
                    id="link-calendly-direct"
                    href="https://calendly.com/sumitsingh9182"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-3 rounded-full bg-[#FF8F33]/20 hover:bg-[#FF8F33] border border-[#FF8F33]/40 hover:border-[#FF8F33] text-[#FF8F33] hover:text-stone-950 font-sans text-xs font-bold tracking-wide transition-all duration-300 flex items-center gap-2 group/cal cursor-pointer"
                  >
                    <Calendar className="w-4 h-4 text-[#FF8F33] group-hover/cal:text-stone-950 transition-colors duration-300" />
                    Book on Calendly
                  </a>

                  <a
                    id="link-whatsapp"
                    href="https://wa.me/918210458586"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-3 rounded-full bg-emerald-500/10 hover:bg-emerald-600 border border-emerald-500/20 hover:border-emerald-600 text-emerald-400 hover:text-stone-950 font-sans text-xs font-bold tracking-wide transition-all duration-300 flex items-center gap-2 group/wa cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 text-emerald-400 group-hover/wa:text-stone-950 transition-colors duration-300" />
                    WhatsApp Chat
                  </a>

                  <a
                    id="link-email"
                    href="mailto:sumitsingh9182@gmail.com"
                    onClick={(e) => {
                      if (onEmailClick) {
                        e.preventDefault();
                        onEmailClick();
                      }
                    }}
                    className="px-4 py-3 rounded-full bg-[#FF8F33]/10 hover:bg-[#FF8F33] border border-[#FF8F33]/20 hover:border-[#FF8F33] text-[#FF8F33] hover:text-stone-950 font-sans text-xs font-bold tracking-wide transition-all duration-300 flex items-center gap-2 group/mail cursor-pointer"
                  >
                    <Mail className="w-4 h-4 text-[#FF8F33] group-hover/mail:text-stone-950 transition-colors duration-300" />
                    sumitsingh9182@gmail.com
                  </a>

                  <a
                    id="link-phone"
                    href="tel:+918210458586"
                    className="px-4 py-3 rounded-full bg-stone-900/60 hover:bg-stone-900 border border-stone-850 hover:border-[#FF8F33]/40 text-stone-200 hover:text-[#FF8F33] transition-all duration-300 flex items-center gap-2 text-xs font-semibold tracking-wide"
                  >
                    <Phone className="w-4 h-4 text-[#E5A463]" />
                    +91 8210458586
                  </a>

                  <a
                    id="link-linkedin"
                    href="https://www.linkedin.com/in/sumit-singh-08b702370/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-3 rounded-full bg-stone-900/60 hover:bg-stone-900 border border-stone-850 hover:border-[#FF8F33]/40 text-stone-200 hover:text-[#FF8F33] transition-all duration-300 flex items-center gap-2 text-xs font-semibold tracking-wide"
                  >
                    <Linkedin className="w-4 h-4 text-[#E5A463]" />
                    LinkedIn
                  </a>
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* Right Column: Calendly booking */}
          <ScrollReveal direction="up" duration={0.8} delay={0.1}>
            <div
              id="contact-form-card"
              className="p-8 md:p-12 rounded-3xl border border-[#231B17] bg-[#14100E] flex flex-col justify-between text-left relative min-h-[460px] h-full"
            >
              <div>
                {/* Header with Location info */}
                <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
                  <h3 className="font-serif text-2xl sm:text-3xl font-normal text-stone-100">
                    Let's work together.
                  </h3>
                  <div className="flex items-center gap-1 text-xs font-mono text-stone-500">
                    <MapPin className="w-3.5 h-3.5 text-[#FF8F33]" />
                    New Delhi, Delhi, India • remote worldwide
                  </div>
                </div>

                <div className="space-y-5 py-2">
                  {/* Premium Call description */}
                  <div className="p-4 rounded-2xl bg-[#FF8F33]/5 border border-[#FF8F33]/10 text-left">
                    <h4 className="font-sans text-sm font-bold text-stone-200 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#FF8F33] animate-ping" />
                      Creative Discovery Call
                    </h4>
                    <p className="font-sans text-xs text-stone-400 mt-2 leading-relaxed">
                      Let's sync up directly to align on your creative requirements, project timeline, corporate AI video production, or fractional retainer scope.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-xl border border-stone-900 bg-stone-950/40 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#FF8F33]/10 border border-[#FF8F33]/20 flex items-center justify-center text-[#FF8F33] shrink-0">
                        <Clock className="w-4 h-4" />
                      </div>
                      <div className="text-left">
                        <span className="font-mono text-[9px] text-stone-500 block uppercase tracking-wider">Duration</span>
                        <span className="font-sans text-xs font-bold text-stone-300">15 - 30 Mins</span>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl border border-stone-900 bg-stone-950/40 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                        <Video className="w-4 h-4" />
                      </div>
                      <div className="text-left">
                        <span className="font-mono text-[9px] text-stone-500 block uppercase tracking-wider">Platform</span>
                        <span className="font-sans text-xs font-bold text-stone-300">Google Meet</span>
                      </div>
                    </div>
                  </div>

                  <a
                    id="calendly-booking-btn"
                    href="https://calendly.com/sumitsingh9182"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-4 rounded-xl bg-[#FF8F33] hover:bg-[#FF8F33]/90 text-[#0C0908] font-sans font-bold text-sm uppercase tracking-wider flex items-center justify-center gap-2 hover:scale-[1.01] transition-all cursor-pointer shadow-lg shadow-[#FF8F33]/15 mt-4 group"
                  >
                    Open Calendly Scheduler
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                  </a>

                  <p className="font-sans text-[10px] text-stone-500 text-center leading-normal pt-2">
                    Can't find a slot? Message me via <button onClick={onEmailClick} className="text-[#FF8F33] hover:underline cursor-pointer">Email</button> or <a href="https://wa.me/918210458586" target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:underline">WhatsApp</a>.
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>

        </div>
      </div>
    </section>
  );
}

