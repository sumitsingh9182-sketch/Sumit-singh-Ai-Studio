import React from "react";
import { PILLARS_DATA } from "../data";
import { Layers, Film, Compass, Clapperboard } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

export default function Pillars() {
  // Map icons to each pillar for premium design accents
  const getPillarIcon = (id: string) => {
    switch (id) {
      case "01":
        return <Layers className="w-5 h-5 text-[#FF8F33]" />;
      case "02":
        return <Film className="w-5 h-5 text-[#FF8F33]" />;
      case "03":
        return <Compass className="w-5 h-5 text-[#FF8F33]" />;
      case "04":
        return <Clapperboard className="w-5 h-5 text-[#FF8F33]" />;
      default:
        return null;
    }
  };

  return (
    <section id="pillars" className="py-16 md:py-20 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <ScrollReveal direction="up">
          {/* Section Heading */}
          <div className="text-left mb-12">
            <span className="font-mono text-[10px] text-[#E5A463] tracking-[0.25em] font-semibold block mb-2 uppercase">
              THE PROGRAM
            </span>
            <h2 id="pillars-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-normal text-stone-100 tracking-tight leading-[1.05]">
              Four Pillars. <br />
              <span className="italic text-[#FF8F33] font-serif">One Cinematic Pipeline.</span>
            </h2>
          </div>
        </ScrollReveal>

        {/* Pillars Grid */}
        <ScrollReveal direction="up" delay={0.15}>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {PILLARS_DATA.pillars.map((pillar) => (
              <div
                key={pillar.id}
                id={`pillar-card-${pillar.id}`}
                className="p-6 md:p-8 rounded-2xl border border-stone-900 bg-[#14100E] hover:bg-[#1B1411]/50 transition-all duration-300 flex flex-col justify-between items-start text-left group glow-card min-h-[220px]"
              >
                <div className="w-full">
                  {/* Number & Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="p-2.5 rounded bg-stone-950/80 border border-stone-850/60 group-hover:border-[#FF8F33]/20 transition-all">
                      {getPillarIcon(pillar.id)}
                    </div>
                    <span className="font-mono text-xs text-stone-500 group-hover:text-[#FF8F33] transition-colors font-semibold">
                      {pillar.id}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-sans text-lg font-bold text-stone-100 mb-3 group-hover:text-[#E5A463] transition-colors">
                    {pillar.title}
                  </h3>

                  {/* Description */}
                  <p className="font-sans text-xs md:text-sm text-stone-400 leading-relaxed">
                    {pillar.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
