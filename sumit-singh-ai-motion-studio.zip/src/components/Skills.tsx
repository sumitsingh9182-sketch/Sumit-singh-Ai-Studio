import React from "react";
import { SKILLS_DATA } from "../data";
import { Check, Cpu, Award, Zap } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

export default function Skills() {
  return (
    <section id="skills" className="py-16 md:py-20 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Section Header */}
        <ScrollReveal direction="up">
          <div className="text-left mb-12">
            <span className="font-mono text-[10px] text-[#FF8F33] tracking-[0.25em] font-semibold block mb-2 uppercase">
              EXPERTISE
            </span>
            <h2 id="skills-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-stone-100 tracking-tight leading-[1.05]">
              Skills & Tools Mapping
            </h2>
          </div>
        </ScrollReveal>

        {/* 3-Column Bento Grid */}
        <ScrollReveal direction="up" delay={0.15}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Column 1: Core Skills */}
            <div
              id="skills-core-card"
              className="p-6 md:p-8 rounded-2xl border border-stone-900 bg-[#14100E] hover:border-[#FF8F33]/10 transition-colors duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2.5 mb-6">
                  <div className="w-8 h-8 rounded bg-[#FF8F33]/10 border border-[#FF8F33]/25 flex items-center justify-center">
                    <Award className="w-4 h-4 text-[#FF8F33]" />
                  </div>
                  <h3 className="font-sans font-bold text-lg text-stone-100 uppercase tracking-wide">
                    Core Skills
                  </h3>
                </div>
                
                <ul className="space-y-3">
                  {SKILLS_DATA.coreSkills.map((skill) => (
                    <li
                      key={skill}
                      className="flex items-start gap-2.5 text-xs md:text-sm text-stone-300 leading-relaxed text-left"
                    >
                      <Check className="w-4 h-4 text-[#FF8F33] mt-0.5 flex-shrink-0" />
                      <span>{skill}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Column 2: Software Proficiency */}
            <div
              id="skills-software-card"
              className="p-6 md:p-8 rounded-2xl border border-stone-900 bg-[#14100E] hover:border-[#FF8F33]/10 transition-colors duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2.5 mb-6">
                  <div className="w-8 h-8 rounded bg-[#E5A463]/10 border border-[#E5A463]/25 flex items-center justify-center">
                    <Cpu className="w-4 h-4 text-[#E5A463]" />
                  </div>
                  <h3 className="font-sans font-bold text-lg text-stone-100 uppercase tracking-wide">
                    Software Proficiency
                  </h3>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {SKILLS_DATA.softwareProficiency.map((software) => (
                    <span
                      key={software}
                      className="px-3 py-2 rounded-lg bg-stone-900 border border-stone-850/60 hover:border-[#E5A463]/30 hover:bg-stone-900/90 text-stone-300 font-sans font-medium text-xs tracking-wide transition-all duration-200 cursor-default"
                    >
                      {software}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Ambient creative design cue */}
              <div className="mt-8 pt-4 border-t border-stone-900 text-left">
                <p className="font-mono text-[10px] text-stone-500 uppercase tracking-wider">
                  Industrial Standard Pipelines
                </p>
              </div>
            </div>

            {/* Column 3: AI Creative Tools */}
            <div
              id="skills-ai-card"
              className="p-6 md:p-8 rounded-2xl border border-stone-900 bg-[#14100E] hover:border-[#FF8F33]/10 transition-colors duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2.5 mb-6">
                  <div className="w-8 h-8 rounded bg-[#FF8F33]/10 border border-[#FF8F33]/25 flex items-center justify-center">
                    <Zap className="w-4 h-4 text-[#FF8F33]" />
                  </div>
                  <h3 className="font-sans font-bold text-lg text-stone-100 uppercase tracking-wide">
                    AI Creative Tools
                  </h3>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {SKILLS_DATA.aiCreativeTools.map((tool) => (
                    <span
                      key={tool}
                      className="px-3 py-2 rounded-lg bg-[#1B1411]/40 border border-[#FF8F33]/15 hover:border-[#FF8F33]/40 hover:bg-[#1B1411]/75 text-stone-300 font-sans font-semibold text-xs tracking-wide transition-all duration-200 flex items-center gap-1.5 cursor-default"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-[#FF8F33]" />
                      {tool}
                    </span>
                  ))}
                </div>
              </div>

              {/* Ambient tech design cue */}
              <div className="mt-8 pt-4 border-t border-stone-900 text-left">
                <p className="font-mono text-[10px] text-[#FF8F33] uppercase tracking-wider font-semibold">
                  State-of-the-art Generative pre-vis
                </p>
              </div>
            </div>

          </div>
        </ScrollReveal>

      </div>
    </section>
  );
}

