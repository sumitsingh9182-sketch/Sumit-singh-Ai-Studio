import React from "react";
import { Play, ArrowUpRight, Award, TrendingUp } from "lucide-react";
import { HERO_DATA } from "../data";
import { motion } from "motion/react";

interface HeroProps {
  onWatchShowreel: () => void;
  onContactClick: () => void;
}

export default function Hero({ onWatchShowreel, onContactClick }: HeroProps) {
  // Use the high quality custom portrait image from HERO_DATA (Google Drive)
  const portraitUrl = HERO_DATA.portraitUrl;

  return (
    <section
      id="home"
      className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-x-clip"
    >
      {/* Background ambient glows */}
      <div className="absolute top-1/4 right-0 w-[400px] h-[400px] bg-[#FF8F33]/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 left-1/4 w-[300px] h-[300px] bg-[#E5A463]/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col gap-12 md:gap-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center lg:items-start">
          {/* Left column: Text Content */}
          <div className="lg:col-span-7 flex flex-col items-start z-10">
          <motion.div
            id="availability-badge"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 mb-6 w-fit shadow-sm shadow-emerald-500/5 backdrop-blur-sm"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-mono text-[10px] tracking-wider uppercase font-bold">
              Currently available for new projects
            </span>
          </motion.div>

          <motion.div
            id="hero-subtitle"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="flex items-center gap-2 mb-4"
          >
            <span className="w-1.5 h-1.5 bg-[#FF8F33] rounded-full animate-pulse" />
            <span className="font-mono text-xs md:text-sm text-stone-400 tracking-[0.2em] font-semibold uppercase">
              AI MOTION DESIGNER
            </span>
          </motion.div>

          <motion.h1
            id="hero-title"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-normal leading-[0.95] text-stone-100 tracking-tight"
          >
            Build a <br />
            Cinematic Brand <br />
            <span className="italic font-normal text-transparent bg-clip-text bg-gradient-to-r from-[#FF8F33] via-[#E5A463] to-[#FF8F33] block sm:inline mt-1 sm:mt-0 font-serif pr-4">
              That Sells 24/7
            </span>
          </motion.h1>

          <motion.p
            id="hero-desc"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-stone-300 font-sans text-base md:text-lg leading-relaxed max-w-xl mt-6 mb-8 text-left"
          >
            Hi, I'm Sumit Singh. A Director, Designer, and AI Motion Specialist crafting premium visuals that elevate stories and brands worldwide. Specializing in high-concept AI-driven pipelines.
          </motion.p>

          <motion.div
            id="hero-buttons"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap items-center gap-4 w-full justify-start"
          >
            <button
              id="hero-watch-btn"
              onClick={onWatchShowreel}
              className="px-6 py-4 rounded-full bg-[#FF8F33] text-[#0C0908] font-sans font-bold text-sm uppercase tracking-wider hover:bg-[#FF8F33]/90 active:scale-95 transition-all duration-200 cursor-pointer flex items-center gap-2 shadow-xl shadow-[#FF8F33]/15 group"
            >
              <span className="w-5 h-5 rounded-full bg-[#0C0908] flex items-center justify-center">
                <Play className="w-2.5 h-2.5 text-[#FF8F33] fill-[#FF8F33] translate-x-[1px]" />
              </span>
              Watch Showreel
            </button>

            <a
              id="hero-resume-btn"
              href={HERO_DATA.resumeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-4 rounded-full border border-[#FF8F33]/25 hover:border-[#FF8F33]/65 hover:bg-[#1B1411]/30 text-stone-100 font-sans font-semibold text-sm uppercase tracking-wider active:scale-95 transition-all duration-200 flex items-center gap-2 group cursor-pointer"
            >
              My Resume
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 text-[#E5A463] transition-transform" />
            </a>

            <button
              id="hero-contact-btn"
              onClick={onContactClick}
              className="px-6 py-4 rounded-full border border-stone-800 hover:border-stone-600 hover:bg-stone-900/40 text-stone-300 font-sans font-semibold text-sm uppercase tracking-wider active:scale-95 transition-all duration-200 flex items-center gap-2 group cursor-pointer"
            >
              Hire Me
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </motion.div>
        </div>

        {/* Right column: Image and Overlay badges */}
        <div className="lg:col-span-5 flex justify-center lg:justify-end items-center lg:items-start relative z-10 lg:pt-6">
          <motion.div
            id="hero-portrait-container"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative w-full max-w-[380px] aspect-[3/4] rounded-2xl border border-[#271E1A] bg-[#15100E] p-3 shadow-2xl shadow-black/40 group overflow-visible"
          >
            {/* The main portrait */}
            <div className="w-full h-full rounded-xl overflow-hidden bg-stone-900 relative">
              <img
                id="hero-portrait-img"
                src={portraitUrl}
                alt="Sumit Singh Portrait"
                className="w-full h-full object-cover grayscale brightness-90 hover:grayscale-0 transition-all duration-700 ease-out group-hover:scale-102"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0C0908]/60 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Floating Badge 1: YOUR SHOWREEL (Top Right) */}
            <motion.div
              id="badge-showreel"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              onClick={onWatchShowreel}
              className="absolute -top-4 -right-4 sm:-right-8 bg-[#1B1411]/95 border border-[#3E2E26] hover:border-[#FF8F33]/40 p-4 rounded-xl shadow-xl shadow-black/30 backdrop-blur-md w-[200px] cursor-pointer hover:scale-105 transition-all duration-300 z-20 group/badge"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-mono text-[9px] text-[#FF8F33] tracking-widest font-semibold">
                  {HERO_DATA.showreelTitle}
                </span>
                <span className="flex items-center gap-1 bg-[#FF8F33]/10 px-1.5 py-0.5 rounded text-[8px] text-[#FF8F33] font-mono font-medium uppercase tracking-wider">
                  <span className="w-1 h-1 bg-[#FF8F33] rounded-full animate-ping" />
                  Running
                </span>
              </div>
              <p className="font-sans font-bold text-xs text-stone-100 uppercase tracking-wide group-hover/badge:text-[#FF8F33] transition-colors">
                {HERO_DATA.showreelCategory}
              </p>
              <p className="font-mono text-[9px] text-stone-500 mt-0.5">
                {HERO_DATA.showreelYear}
              </p>
              
              {/* Fake player play bar */}
              <div className="mt-3 flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-[#FF8F33] flex items-center justify-center flex-shrink-0">
                  <Play className="w-2 h-2 text-[#0C0908] fill-[#0C0908] translate-x-[0.5px]" />
                </div>
                <div className="w-full bg-stone-800 h-1 rounded-full overflow-hidden">
                  <div className="w-3/4 bg-[#FF8F33] h-full rounded-full animate-[shimmer_2s_infinite]" />
                </div>
              </div>
            </motion.div>

            {/* Floating Badge 2: PROJECTS SHIPPED (Bottom Right/Overlay) */}
            <motion.div
              id="badge-shipped"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="absolute -bottom-2 -left-4 sm:-left-8 bg-[#1B1411]/95 border border-[#3E2E26] p-4 rounded-xl shadow-xl shadow-black/30 backdrop-blur-md w-[180px] z-20 cursor-default"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-[9px] text-stone-400 tracking-wider">
                  PROJECTS SHIPPED
                </span>
                <TrendingUp className="w-3 h-3 text-[#FF8F33]" />
              </div>
              <p className="font-serif text-3xl font-bold text-[#E5A463] mt-1 leading-none">
                {HERO_DATA.projectsShippedCount}
              </p>
              
              {/* Avatars simulation */}
              <div className="mt-3 flex items-center gap-1.5">
                <div className="flex -space-x-2">
                  <div className="w-5 h-5 rounded-full bg-stone-700 border border-stone-800 text-[8px] flex items-center justify-center font-bold text-stone-300">T</div>
                  <div className="w-5 h-5 rounded-full bg-stone-600 border border-stone-800 text-[8px] flex items-center justify-center font-bold text-stone-300">A</div>
                  <div className="w-5 h-5 rounded-full bg-stone-500 border border-stone-800 text-[8px] flex items-center justify-center font-bold text-stone-300">L</div>
                </div>
                <span className="font-mono text-[9px] text-stone-400">
                  {HERO_DATA.brandsCount}
                </span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

        {/* Featured Publications - Full Width */}
        <motion.div
          id="hero-featured"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="pt-8 border-t border-stone-900/60 w-full z-10"
        >
          <span className="font-mono text-[10px] text-stone-500 tracking-[0.25em] font-semibold block mb-4 uppercase">
            Featured In
          </span>
          <div className="flex flex-wrap items-center justify-between md:justify-start gap-x-6 sm:gap-x-8 md:gap-x-10 lg:gap-x-12 gap-y-4 text-stone-500 text-sm font-semibold">
            {HERO_DATA.featuredIn.map((logo) => (
              <span
                key={logo}
                id={`featured-logo-${logo.toLowerCase().replace(/\s/g, '-')}`}
                className="hover:text-stone-300 transition-colors cursor-default whitespace-nowrap"
              >
                {logo}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
