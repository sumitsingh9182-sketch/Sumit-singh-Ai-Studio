import React, { useState } from "react";
import { X, Mail, Copy, Check, ExternalLink, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface EmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  emailAddress: string;
}

export default function EmailModal({ isOpen, onClose, emailAddress }: EmailModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(emailAddress);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy email address: ", err);
    }
  };

  const emailServices = [
    {
      name: "Open in Gmail",
      description: "Directly compose using Gmail Web Client",
      url: `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(emailAddress)}`,
      icon: (
        <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center shrink-0">
          <Mail className="w-5 h-5" />
        </div>
      ),
      highlight: true
    },
    {
      name: "Open in Outlook",
      description: "Directly compose using Outlook Web Client",
      url: `https://outlook.live.com/default.aspx?rru=compose&to=${encodeURIComponent(emailAddress)}`,
      icon: (
        <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
          <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
            <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm.224 16h-4.448v-8h4.448c2.206 0 4 1.794 4 4s-1.794 4-4 4z" />
          </svg>
        </div>
      ),
      highlight: false
    },
    {
      name: "Default Mail Client",
      description: "Launch your device's native mail app",
      url: `mailto:${emailAddress}`,
      icon: (
        <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
          <ExternalLink className="w-5 h-5" />
        </div>
      ),
      highlight: false
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Overlay backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#0C0908]/90 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 15 }}
            transition={{ type: "spring", duration: 0.4 }}
            className="w-full max-w-md bg-[#14100E] border border-stone-800 rounded-2xl overflow-hidden relative z-10 shadow-2xl"
          >
            {/* Top close trigger */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-stone-500 hover:text-stone-300 transition-colors p-1.5 rounded-lg hover:bg-stone-900 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="p-6 pb-4 border-b border-stone-900 text-left">
              <span className="font-mono text-[9px] text-[#FF8F33] tracking-[0.2em] font-semibold uppercase block mb-1">
                Direct Contact
              </span>
              <h3 className="font-serif text-xl font-medium text-stone-100 tracking-tight">
                Get in touch via Email
              </h3>
              <p className="font-sans text-xs text-stone-400 mt-1">
                Choose your preferred web client or copy the address.
              </p>
            </div>

            {/* Quick Copy Action Box */}
            <div className="p-6 pb-2">
              <div className="flex items-center justify-between gap-3 bg-stone-950 p-3 rounded-xl border border-stone-900">
                <div className="flex flex-col min-w-0">
                  <span className="font-mono text-[9px] text-stone-500 uppercase tracking-wider">
                    Email Address
                  </span>
                  <span className="font-mono text-xs text-stone-200 select-all truncate">
                    {emailAddress}
                  </span>
                </div>
                <button
                  onClick={handleCopy}
                  className={`px-4 py-2 rounded-lg font-sans text-xs font-bold transition-all duration-300 flex items-center gap-1.5 shrink-0 cursor-pointer ${
                    copied
                      ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                      : "bg-[#FF8F33] hover:bg-[#FF8F33]/90 text-[#0C0908]"
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Address
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Service Options List */}
            <div className="p-6 pt-2 flex flex-col gap-3">
              {emailServices.map((srv, idx) => (
                <a
                  key={idx}
                  href={srv.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={onClose}
                  className={`p-3.5 rounded-xl border flex items-center justify-between transition-all duration-300 group/item cursor-pointer text-left ${
                    srv.highlight 
                      ? "bg-[#FF8F33]/5 border-[#FF8F33]/20 hover:border-[#FF8F33]/60" 
                      : "bg-[#1C1715]/40 border-stone-850 hover:border-[#FF8F33]/40"
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    {srv.icon}
                    <div className="flex flex-col min-w-0">
                      <span className={`font-sans text-xs font-bold ${srv.highlight ? "text-[#E5A463]" : "text-stone-200"} group-hover/item:text-[#FF8F33] transition-colors`}>
                        {srv.name}
                      </span>
                      <span className="font-sans text-[11px] text-stone-400 mt-0.5 truncate">
                        {srv.description}
                      </span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-stone-600 group-hover/item:text-[#FF8F33] group-hover/item:translate-x-1 transition-all duration-300 shrink-0" />
                </a>
              ))}
            </div>

            {/* Help/Status Footer inside Modal */}
            <div className="bg-stone-950 p-4 border-t border-stone-900 flex justify-center">
              <p className="font-mono text-[9px] text-stone-500 text-center tracking-wide uppercase">
                Active Mail Channel &bull; Checked 2026
              </p>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
