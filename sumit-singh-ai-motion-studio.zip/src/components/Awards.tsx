import React, { useState } from "react";
import { Award, ChevronRight, X, Sparkles, BookOpen } from "lucide-react";
import { AWARDS_DATA } from "../data";
import { motion, AnimatePresence } from "motion/react";
import ScrollReveal from "./ScrollReveal";

export default function Awards() {
  const [selectedCase, setSelectedCase] = useState<string | null>(null);

  const handleCaseClick = (id: string) => {
    setSelectedCase(selectedCase === id ? null : id);
  };

  return (
    <section id="awards" className="py-16 md:py-24 relative">
      {/* Background radial highlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-[#E5A463]/3 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <ScrollReveal direction="up">
          {/* Main Awards Box */}
          <div className="border border-[#231B17] bg-[#14100E] rounded-3xl p-8 md:p-14 relative overflow-hidden">
            {/* Subtle Award Emblem Logo on top right of the container */}
            <div className="absolute top-6 right-8 opacity-10 text-[#FF8F33] hidden sm:block">
              <Award className="w-24 h-24 stroke-[1]" />
            </div>

            <div className="max-w-3xl flex flex-col items-start text-left mb-12">
              <div className="flex items-center gap-2 mb-3">
                <Award className="w-4 h-4 text-[#FF8F33]" />
                <span className="font-mono text-xs text-stone-400 tracking-[0.2em] font-semibold uppercase">
                  {AWARDS_DATA.category}
                </span>
              </div>
              
              <h2 id="awards-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-normal leading-[1.05] text-stone-100 tracking-tight">
                Two 2026 Telly Award wins for <br className="hidden sm:inline" />
                <span className="italic text-[#FF8F33] font-serif">Gen AI-driven education work.</span>
              </h2>
              
              <p id="awards-desc" className="text-stone-400 font-sans text-sm md:text-base leading-relaxed mt-6 max-w-2xl">
                {AWARDS_DATA.description}
              </p>
            </div>

            {/* Sub cards: Case Studies Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              {AWARDS_DATA.caseStudies.map((item) => {
                const isExpanded = selectedCase === item.id;
                return (
                  <div
                    key={item.id}
                    id={`award-case-${item.id}`}
                    className={`p-6 md:p-8 rounded-2xl border transition-all duration-300 flex flex-col justify-between items-start text-left bg-[#1B1411]/50 relative ${
                      isExpanded 
                        ? "border-[#FF8F33]/40 bg-[#1B1411]" 
                        : "border-stone-850 hover:border-stone-700 hover:bg-[#1B1411]/80"
                    }`}
                  >
                    <div className="w-full">
                      {/* Badge */}
                      <div className="flex items-center justify-between mb-4">
                        <span className="flex items-center gap-1.5 bg-[#FF8F33]/10 px-2.5 py-1 rounded-full text-[10px] text-[#FF8F33] font-mono font-bold uppercase tracking-wider">
                          <Sparkles className="w-3 h-3" />
                          {item.category}
                        </span>
                        <Award className="w-4 h-4 text-[#E5A463]/40" />
                      </div>

                      {/* Title */}
                      <h3 className="font-serif text-xl sm:text-2xl text-stone-100 font-medium tracking-tight mb-2 leading-tight">
                        {item.title}
                      </h3>
                      
                      {/* Subtitle */}
                      <p className="font-mono text-[11px] text-[#E5A463] mb-4">
                        {item.subtitle}
                      </p>

                      {/* Short Description */}
                      <p className="font-sans text-xs md:text-sm text-stone-400 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Extra Detailed Content (Visible when expanded) */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.25 }}
                            className="overflow-hidden mt-4 pt-4 border-t border-stone-800/60"
                          >
                            <h4 className="font-mono text-[10px] text-stone-300 font-bold tracking-wider mb-2 uppercase flex items-center gap-1">
                               <BookOpen className="w-3 h-3 text-[#FF8F33]" />
                               Motion System Details
                            </h4>
                            <p className="text-xs text-stone-400 leading-relaxed mb-3">
                              This project required setting up standard character rigging pipelines where keyframe coordinates were synced to generative AI background renders. Utilizing high-fidelity animation scripts and automated lighting rigs in Cinema 4D, the final output slashed manual scene-assembly times from weeks to days.
                            </p>
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              <span className="text-[9px] font-mono px-2 py-0.5 bg-stone-900 rounded border border-stone-800 text-stone-400">After Effects</span>
                              <span className="text-[9px] font-mono px-2 py-0.5 bg-stone-900 rounded border border-stone-800 text-stone-400">Runway Gen-2</span>
                              <span className="text-[9px] font-mono px-2 py-0.5 bg-stone-900 rounded border border-stone-800 text-stone-400">Cinema 4D</span>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Toggle button */}
                    <button
                      id={`btn-case-toggle-${item.id}`}
                      onClick={() => handleCaseClick(item.id)}
                      className="mt-6 flex items-center gap-1 text-xs font-mono text-[#E5A463] hover:text-[#FF8F33] uppercase tracking-wider font-semibold group cursor-pointer"
                    >
                      {isExpanded ? "Close case detail" : "View case study"}
                      <ChevronRight className={`w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform duration-200 ${isExpanded ? "rotate-90" : ""}`} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
