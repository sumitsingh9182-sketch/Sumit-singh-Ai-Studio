import React from "react";
import { EXPERIENCE_DATA } from "../data";
import { Briefcase, Calendar } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

export default function Experience() {
  return (
    <section id="experience" className="py-16 md:py-20 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Section Header */}
        <ScrollReveal direction="up">
          <div className="text-left mb-12">
            <span className="font-mono text-[10px] text-[#FF8F33] tracking-[0.25em] font-semibold block mb-2 uppercase">
              HISTORY
            </span>
            <h2 id="experience-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-stone-100 tracking-tight leading-[1.05]">
              Professional Experience
            </h2>
          </div>
        </ScrollReveal>

        {/* Experience Grid (2 columns, 2 rows) */}
        <ScrollReveal direction="up" delay={0.15}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {EXPERIENCE_DATA.map((item) => (
              <div
                key={item.id}
                id={`experience-card-${item.id}`}
                className="p-6 md:p-8 rounded-2xl border border-stone-900 bg-[#14100E] hover:border-[#FF8F33]/15 hover:bg-[#1B1411]/30 transition-all duration-300 text-left flex flex-col justify-between"
              >
                <div>
                  {/* Card Header: Role & Period */}
                  <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-stone-900 border border-stone-800 flex items-center justify-center">
                        <Briefcase className="w-3.5 h-3.5 text-[#E5A463]" />
                      </div>
                      <div>
                        <h3 className="font-sans font-bold text-base md:text-lg text-stone-100">
                          {item.role}
                        </h3>
                        <p className="font-mono text-[11px] text-[#E5A463]/80 uppercase tracking-wider mt-0.5">
                          {item.company}
                        </p>
                      </div>
                    </div>
                    
                    {/* Timeline Badge */}
                    <div className="px-3 py-1 rounded-full bg-[#FF8F33]/5 border border-[#FF8F33]/25 flex items-center gap-1.5 text-[10px] font-mono text-[#FF8F33] font-semibold">
                      <Calendar className="w-3 h-3" />
                      {item.period}
                    </div>
                  </div>

                  {/* Bullet Points */}
                  <ul className="space-y-3.5 pl-1">
                    {item.bullets.map((bullet, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-2.5 text-xs md:text-sm text-stone-300 leading-relaxed"
                      >
                        {/* Custon circular bullet in amber */}
                        <span className="w-1.5 h-1.5 rounded-full bg-[#FF8F33] mt-[7px] flex-shrink-0" />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </ScrollReveal>

      </div>
    </section>
  );
}

