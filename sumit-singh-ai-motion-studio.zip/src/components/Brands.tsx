import React, { useState } from "react";
import { ShieldCheck } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

interface BrandLogoProps {
  name: string;
  domain: string;
  color: string;
  fallbackIcon: React.ReactNode;
}

function BrandLogo({ name, domain, color, fallbackIcon }: BrandLogoProps) {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  if (error) {
    return (
      <div 
        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-110" 
        style={{ backgroundColor: `${color}15` }}
      >
        {fallbackIcon}
      </div>
    );
  }

  return (
    <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 relative overflow-hidden bg-stone-900 group-hover:scale-110 transition-transform duration-300 p-1">
      <img
        src={`https://logo.clearbit.com/${domain}`}
        alt={`${name} Logo`}
        referrerPolicy="no-referrer"
        onLoad={() => setLoading(false)}
        onError={() => setError(true)}
        className={`w-full h-full object-contain rounded-sm transition-opacity duration-350 ${
          loading ? "opacity-0" : "opacity-100"
        }`}
      />
      {loading && (
        <div 
          className="absolute inset-0 flex items-center justify-center"
          style={{ backgroundColor: `${color}15` }}
        >
          {fallbackIcon}
        </div>
      )}
    </div>
  );
}

const ROW1_BRANDS = [
  {
    name: "Zerodha",
    domain: "zerodha.com",
    color: "#4488fa",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L4 12l8 10 8-10L12 2z" stroke="#4488fa" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="12" cy="12" r="3" fill="#4488fa"/>
      </svg>
    )
  },
  {
    name: "CRED",
    domain: "cred.club",
    color: "#ffffff",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <polygon points="12,2 22,8 22,16 12,22 2,16 2,8" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <polygon points="12,6 18,10 18,14 12,18 6,14 6,10" fill="#ffffff" opacity="0.3"/>
      </svg>
    )
  },
  {
    name: "Razorpay",
    domain: "razorpay.com",
    color: "#1364f1",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M19 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5a2 2 0 00-2-2z" stroke="#1364f1" strokeWidth="2"/>
        <path d="M8 15l4-7 4 7-4-2-4 2z" fill="#1364f1"/>
      </svg>
    )
  },
  {
    name: "upGrad",
    domain: "upgrad.com",
    color: "#e21223",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M3 20h18M3 15h12M3 10h6" stroke="#e21223" strokeWidth="2" strokeLinecap="round"/>
        <path d="M14 6l4-4 4 4M18 2v13" stroke="#e21223" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "Unacademy",
    domain: "unacademy.com",
    color: "#15c58a",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" stroke="#15c58a" strokeWidth="2"/>
        <path d="M8 12a4 4 0 018 0" stroke="#15c58a" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    name: "boAt",
    domain: "boat-lifestyle.com",
    color: "#e31c25",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M6 18V6l12 6-12 6z" stroke="#e31c25" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M18 6v12" stroke="#e31c25" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    name: "Nykaa",
    domain: "nykaa.com",
    color: "#e80074",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="#e80074"/>
      </svg>
    )
  },
  {
    name: "Meesho",
    domain: "meesho.com",
    color: "#ff5656",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M4 4h16v16H4V4z" stroke="#ff5656" strokeWidth="2"/>
        <path d="M9 9l3 3 3-3" stroke="#ff5656" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M9 15h6" stroke="#ff5656" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    name: "PhonePe",
    domain: "phonepe.com",
    color: "#5f259f",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <rect x="5" y="2" width="14" height="20" rx="3" stroke="#5f259f" strokeWidth="2"/>
        <path d="M12 18h.01M9 6h6" stroke="#5f259f" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="12" cy="11" r="2" fill="#5f259f"/>
      </svg>
    )
  },
  {
    name: "Lenskart",
    domain: "lenskart.com",
    color: "#00bac6",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <circle cx="7" cy="12" r="4" stroke="#00bac6" strokeWidth="2"/>
        <circle cx="17" cy="12" r="4" stroke="#00bac6" strokeWidth="2"/>
        <path d="M11 12h2" stroke="#00bac6" strokeWidth="2"/>
      </svg>
    )
  },
  {
    name: "Swiggy",
    domain: "swiggy.com",
    color: "#fc8019",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M18 8a6 6 0 00-12 0c0 4 6 11 6 11s6-7 6-11z" stroke="#fc8019" strokeWidth="2"/>
        <circle cx="12" cy="8" r="2" fill="#fc8019"/>
      </svg>
    )
  },
  {
    name: "Zomato",
    domain: "zomato.com",
    color: "#cb202d",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 21a9 9 0 100-18 9 9 0 000 18z" stroke="#cb202d" strokeWidth="2"/>
        <path d="M12 7v10M10 9l2-2 2 2" stroke="#cb202d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "Ola",
    domain: "olacabs.com",
    color: "#a3d82a",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="10" stroke="#a3d82a" strokeWidth="2"/>
        <circle cx="12" cy="12" r="4" fill="#a3d82a"/>
      </svg>
    )
  },
  {
    name: "Paytm",
    domain: "paytm.com",
    color: "#00baf2",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="4" width="18" height="16" rx="3" stroke="#00baf2" strokeWidth="2"/>
        <path d="M7 10h10M7 14h5" stroke="#00baf2" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    name: "Dream11",
    domain: "dream11.com",
    color: "#e21d26",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L3 7v5c0 5.25 3.85 10.17 9 11.5 5.15-1.33 9-6.25 9-11.5V7l-9-5z" stroke="#e21d26" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M12 7l1.5 3 3.5.5-2.5 2.5.5 3.5-3-1.5-3 1.5.5-3.5-2.5-2.5 3.5-.5L12 7z" fill="#e21d26"/>
      </svg>
    )
  }
];

const ROW2_BRANDS = [
  {
    name: "ShareChat",
    domain: "sharechat.com",
    color: "#ff9d00",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 11-7.6-11.4 8.43 8.43 0 015.3 1.9L21 4.5z" stroke="#ff9d00" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "Vedantu",
    domain: "vedantu.com",
    color: "#ea5b0c",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L2 22h20L12 2z" stroke="#ea5b0c" strokeWidth="2" strokeLinejoin="round"/>
        <circle cx="12" cy="14" r="3" fill="#ea5b0c"/>
      </svg>
    )
  },
  {
    name: "Byju's",
    domain: "byjus.com",
    color: "#803289",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" stroke="#803289" strokeWidth="2"/>
        <path d="M9 8h4a2 2 0 010 4H9h5a2 2 0 010 4H9" stroke="#803289" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "CoinDCX",
    domain: "coindcx.com",
    color: "#004de6",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <circle cx="9" cy="12" r="6" stroke="#004de6" strokeWidth="2"/>
        <circle cx="15" cy="12" r="6" stroke="#fbc02d" strokeWidth="2"/>
      </svg>
    )
  },
  {
    name: "Spinny",
    domain: "spinny.com",
    color: "#09bcb4",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="10" stroke="#09bcb4" strokeWidth="2"/>
        <path d="M12 6v6l4 4" stroke="#09bcb4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "Classplus",
    domain: "classplusapp.com",
    color: "#1e53ec",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M22 10v6M2 10l10-5 10 5-10 5z" stroke="#1e53ec" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M6 12.5V16a6 6 0 0012 0v-3.5" stroke="#1e53ec" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "Slice",
    domain: "sliceit.com",
    color: "#18e38d",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M3 3h18M3 21h18M3 12h18" stroke="#18e38d" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="12" cy="12" r="4" fill="#18e38d"/>
      </svg>
    )
  },
  {
    name: "Jupiter",
    domain: "jupiter.money",
    color: "#ff6200",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="8" stroke="#ff6200" strokeWidth="2"/>
        <ellipse cx="12" cy="12" rx="10" ry="2" stroke="#ff6200" strokeWidth="2" transform="rotate(-15 12 12)"/>
      </svg>
    )
  },
  {
    name: "Fi Money",
    domain: "fi.money",
    color: "#00cf85",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M5 21V3h14" stroke="#00cf85" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5 11h10" stroke="#00cf85" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "Jar",
    domain: "jar.app",
    color: "#fbc02d",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 22a8 8 0 008-8V8H4v6a8 8 0 008 8z" stroke="#fbc02d" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M12 2a4 4 0 00-4 4h8a4 4 0 00-4-4z" fill="#fbc02d"/>
      </svg>
    )
  },
  {
    name: "Pepper Content",
    domain: "peppercontent.io",
    color: "#e53935",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" stroke="#e53935" strokeWidth="2"/>
        <path d="M12 6v12M8 10h8" stroke="#e53935" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    name: "Moj",
    domain: "mojapp.in",
    color: "#f9a825",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M5 3l14 9-14 9V3z" stroke="#f9a825" strokeWidth="2" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    name: "Josh",
    domain: "joshapp.co",
    color: "#1a73e8",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="#1a73e8"/>
      </svg>
    )
  },
  {
    name: "Khatabook",
    domain: "khatabook.com",
    color: "#e52b50",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <path d="M4 19.5A2.5 2.5 0 016.5 17H20" stroke="#e52b50" strokeWidth="2" strokeLinecap="round"/>
        <path d="M6 2h14v20H6a2.5 2.5 0 01-2.5-2.5V4.5A2.5 2.5 0 016 2z" stroke="#e52b50" strokeWidth="2"/>
      </svg>
    )
  },
  {
    name: "BrowserStack",
    domain: "browserstack.com",
    color: "#ff8f33",
    icon: (
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="3" width="20" height="14" rx="2" stroke="#ff8f33" strokeWidth="2"/>
        <path d="M6 21h12M12 17v4" stroke="#ff8f33" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    )
  }
];

export default function Brands() {
  return (
    <section id="brands" className="py-16 md:py-24 relative overflow-hidden">
      {/* Dynamic Keyframes injected locally */}
      <style>{`
        @keyframes scroll-left {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.3333%); }
        }
        @keyframes scroll-right {
          0% { transform: translateX(-33.3333%); }
          100% { transform: translateX(0); }
        }
        .animate-scroll-left-loop {
          animation: scroll-left 40s linear infinite;
        }
        .animate-scroll-right-loop {
          animation: scroll-right 40s linear infinite;
        }
        .animate-scroll-left-loop:hover, .animate-scroll-right-loop:hover {
          animation-play-state: paused;
        }
      `}</style>

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        <ScrollReveal direction="up">
          {/* Main Box containing text + sliding rows */}
          <div className="border border-[#231B17] bg-[#14100E] rounded-3xl p-8 md:p-12 overflow-hidden relative">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start mb-10">
              
              {/* Left side: Heading */}
              <div className="lg:col-span-6 flex flex-col items-start text-left">
                <span className="font-mono text-[9px] text-[#FF8F33] tracking-[0.2em] font-semibold mb-2 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  CLIENT WORK
                </span>
                
                <h2 id="brands-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal leading-[1.1] text-stone-100 tracking-tight">
                  Brand motion built for teams <br />
                  <span className="italic text-[#E5A463]">people already trust.</span>
                </h2>
              </div>

              {/* Right side: Description */}
              <div className="lg:col-span-6 text-left lg:pt-6">
                <p id="brands-desc" className="text-stone-400 font-sans text-xs md:text-sm leading-relaxed max-w-xl">
                  A selection of client and brand work across fintech, consumer products, learning, commerce, SaaS, and broadcast-ready campaigns.
                </p>
              </div>

            </div>

            {/* Scrolling Tickers Wrapper */}
            <div className="relative w-full overflow-hidden py-2 flex flex-col gap-4 mt-8">
              {/* Fade overlays */}
              <div className="pointer-events-none absolute top-0 bottom-0 left-0 w-16 sm:w-28 bg-gradient-to-r from-[#14100E] via-[#14100E]/80 to-transparent z-20" />
              <div className="pointer-events-none absolute top-0 bottom-0 right-0 w-16 sm:w-28 bg-gradient-to-l from-[#14100E] via-[#14100E]/80 to-transparent z-20" />

              {/* Row 1: Left scrolling */}
              <div className="flex w-full overflow-x-hidden">
                <div className="flex gap-3 shrink-0 animate-scroll-left-loop">
                  {/* Render 3 copies for a super smooth infinite wrap on any monitor */}
                  {[...ROW1_BRANDS, ...ROW1_BRANDS, ...ROW1_BRANDS].map((brand, i) => (
                    <div
                      key={`row1-${brand.name}-${i}`}
                      id={`brand-badge-${brand.name.toLowerCase().replace(/\s/g, '-')}-${i}`}
                      className="inline-flex items-center gap-3 px-4.5 py-3 rounded-xl bg-stone-900/35 border border-stone-850/40 hover:border-[#FF8F33]/25 hover:bg-stone-900/60 transition-all duration-300 min-w-[155px] sm:min-w-[175px] shrink-0 cursor-default select-none group"
                    >
                      <BrandLogo 
                        name={brand.name} 
                        domain={brand.domain} 
                        color={brand.color} 
                        fallbackIcon={brand.icon} 
                      />
                      <span className="font-sans font-bold text-xs text-stone-300 group-hover:text-stone-100 transition-colors tracking-wide whitespace-nowrap">
                        {brand.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Row 2: Right scrolling */}
              <div className="flex w-full overflow-x-hidden">
                <div className="flex gap-3 shrink-0 animate-scroll-right-loop">
                  {[...ROW2_BRANDS, ...ROW2_BRANDS, ...ROW2_BRANDS].map((brand, i) => (
                    <div
                      key={`row2-${brand.name}-${i}`}
                      id={`brand-badge-${brand.name.toLowerCase().replace(/\s/g, '-')}-${i}`}
                      className="inline-flex items-center gap-3 px-4.5 py-3 rounded-xl bg-stone-900/35 border border-stone-850/40 hover:border-[#E5A463]/25 hover:bg-stone-900/60 transition-all duration-300 min-w-[155px] sm:min-w-[175px] shrink-0 cursor-default select-none group"
                    >
                      <BrandLogo 
                        name={brand.name} 
                        domain={brand.domain} 
                        color={brand.color} 
                        fallbackIcon={brand.icon} 
                      />
                      <span className="font-sans font-bold text-xs text-stone-300 group-hover:text-stone-100 transition-colors tracking-wide whitespace-nowrap">
                        {brand.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}

