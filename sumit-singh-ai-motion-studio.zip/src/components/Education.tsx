import React from "react";
import { EDUCATION_DATA } from "../data";
import { GraduationCap, Calendar } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

export default function Education() {
  return (
    <section id="education" className="py-16 md:py-20 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Section Header */}
        <ScrollReveal direction="up">
          <div className="text-left mb-12">
            <span className="font-mono text-[10px] text-[#E5A463] tracking-[0.25em] font-semibold block mb-2 uppercase">
              ACADEMIC BACKGROUND
            </span>
            <h2 id="education-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-stone-100 tracking-tight leading-[1.05]">
              Education & Credentials
            </h2>
          </div>
        </ScrollReveal>

        {/* 2-Column Grid */}
        <ScrollReveal direction="up" delay={0.15}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {EDUCATION_DATA.map((item) => (
              <div
                key={item.id}
                id={`education-card-${item.id}`}
                className="p-6 md:p-8 rounded-2xl border border-stone-900 bg-[#14100E] hover:border-[#E5A463]/10 transition-colors duration-300 flex items-start justify-between text-left"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-stone-900 border border-stone-850 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <GraduationCap className="w-5 h-5 text-[#E5A463]" />
                  </div>
                  <div>
                    <h3 className="font-sans font-bold text-lg text-stone-100 mb-1 leading-snug">
                      {item.institution}
                    </h3>
                    <p className="font-sans text-xs md:text-sm text-stone-400">
                      {item.degree}
                    </p>
                  </div>
                </div>
                
                {/* Year range badge */}
                <div className="px-3 py-1 rounded-full bg-[#E5A463]/5 border border-[#E5A463]/20 flex items-center gap-1 text-[9px] font-mono text-[#E5A463] font-semibold">
                  <Calendar className="w-3 h-3" />
                  {item.period}
                </div>
              </div>
            ))}
          </div>
        </ScrollReveal>

      </div>
    </section>
  );
}

