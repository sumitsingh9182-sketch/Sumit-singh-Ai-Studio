import React from "react";
import { STATS_DATA } from "../data";
import ScrollReveal from "./ScrollReveal";

export default function Stats() {
  return (
    <section id="stats" className="py-12 md:py-16 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <ScrollReveal direction="up">
          <div className="border border-[#231B17] bg-[#14100E] rounded-2xl p-8 md:p-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative overflow-hidden">
            {/* Subtle accent background line */}
            <div className="absolute top-0 right-1/4 w-32 h-[1px] bg-gradient-to-r from-transparent via-[#FF8F33]/20 to-transparent" />
            
            {/* Left Column: Heading */}
            <div className="lg:col-span-5">
              <h2 id="stats-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-stone-100 tracking-tight leading-[1.05] text-left">
                Proven <span className="italic text-[#FF8F33]">Track Record.</span>
              </h2>
            </div>

            {/* Right Column: 4 Stats Grid */}
            <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-6 sm:gap-4 md:gap-6 border-t lg:border-t-0 lg:border-l border-stone-800/60 pt-8 lg:pt-0 lg:pl-8">
              {STATS_DATA.metrics.map((metric, index) => (
                <div
                  key={index}
                  id={`stat-metric-${index}`}
                  className="flex flex-col items-start text-left group"
                >
                  <span className="font-serif text-3xl md:text-4xl lg:text-5xl font-normal text-[#E5A463] group-hover:text-[#FF8F33] transition-colors duration-300 leading-none">
                    {metric.value}
                  </span>
                  <span className="font-sans text-[11px] sm:text-[10px] md:text-xs text-stone-400 mt-2 leading-relaxed tracking-wide font-medium">
                    {metric.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
