import React from "react";
import { Play, ArrowRight, MonitorPlay } from "lucide-react";
import { PROJECTS_DATA } from "../data";
import { Project } from "../types";
import ScrollReveal from "./ScrollReveal";

interface SelectedWorkProps {
  onPlayProject: (videoUrl: string, title: string) => void;
  onViewAllVideos: () => void;
}

export default function SelectedWork({ onPlayProject, onViewAllVideos }: SelectedWorkProps) {
  // Original logic: Show the first 3 prominent featured works
  const initialProjects = PROJECTS_DATA.slice(0, 3);

  return (
    <section id="work" className="py-16 md:py-24 relative overflow-hidden bg-[#0C0908]">
      {/* Background radial accent glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full bg-[#FF8F33]/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Section Header */}
        <ScrollReveal direction="up">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div className="text-left">
              <span className="font-mono text-[10px] text-[#FF8F33] tracking-[0.25em] font-semibold block mb-2 uppercase">
                PORTFOLIO
              </span>
              <h2 id="work-heading" className="font-serif text-3xl sm:text-4xl md:text-5xl font-normal text-stone-100 tracking-tight leading-[1.05] max-w-2xl">
                Selected Work <br />
                <span className="italic text-[#E5A463] font-serif">Featured Projects.</span>
              </h2>
            </div>

            <div className="flex flex-wrap gap-3 self-start md:self-auto">
              <button
                id="view-all-videos-trigger"
                onClick={onViewAllVideos}
                className="px-5 py-3 rounded-full bg-[#FF8F33] text-[#0C0908] hover:bg-[#FF8F33]/90 font-sans font-bold text-xs uppercase tracking-wider active:scale-95 transition-all duration-200 flex items-center gap-1.5 shadow-lg shadow-[#FF8F33]/15 cursor-pointer"
              >
                Explore The Vault
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                id="view-all-work-btn"
                onClick={() => {
                  const target = document.querySelector("#contact");
                  if (target) {
                    target.scrollIntoView({ behavior: "smooth" });
                  }
                }}
                className="px-5 py-3 rounded-full bg-stone-900/80 border border-stone-800 text-stone-300 hover:text-stone-100 hover:border-stone-700 font-sans font-bold text-xs uppercase tracking-wider active:scale-95 transition-all duration-200 flex items-center gap-1.5 shadow-lg cursor-pointer"
              >
                Get In Touch
              </button>
            </div>
          </div>
        </ScrollReveal>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {initialProjects.map((project: Project) => {
            const isVertical = project.category === "Talking Heads";
            return (
              <div 
                key={project.id} 
                className={isVertical ? "max-w-[290px] mx-auto w-full" : "w-full"}
              >
                <ScrollReveal 
                  direction="up" 
                  delay={0.1}
                  className="h-full w-full"
                >
                  <div
                    id={`project-card-${project.id}`}
                    className="group flex flex-col justify-between items-start text-left rounded-2xl border border-stone-900 bg-[#14100E] p-4 transition-all duration-500 hover:border-stone-850 glow-card h-full w-full"
                  >
                    <div className="w-full">
                      {/* Image Container with Hover Play button */}
                      <div
                        id={`project-thumb-container-${project.id}`}
                        onClick={() => onPlayProject(project.videoUrl, project.title)}
                        className={`w-full rounded-xl overflow-hidden bg-stone-950 relative cursor-pointer ${
                          isVertical ? "aspect-[9/16]" : "aspect-[16/9]"
                        }`}
                      >
                        <img
                          id={`project-thumb-img-${project.id}`}
                          src={project.thumbnail}
                          alt={project.title}
                          className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 ease-out"
                          referrerPolicy="no-referrer"
                        />
                        {/* Hover visual overlays */}
                        <div className="absolute inset-0 bg-[#0C0908]/20 group-hover:bg-[#0C0908]/40 transition-colors duration-300" />
                        
                        {/* Overlay Play Button */}
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="w-12 h-12 rounded-full bg-[#FF8F33] text-[#0C0908] flex items-center justify-center shadow-xl shadow-black/30 scale-90 group-hover:scale-100 transition-all duration-300">
                            <Play className="w-5 h-5 fill-[#0C0908] translate-x-[1px]" />
                          </div>
                        </div>

                        {/* Corner indicator */}
                        <div className="absolute top-3 right-3 bg-[#0C0908]/80 backdrop-blur-md px-2.5 py-1 rounded-full text-[9px] font-mono text-[#E5A463] font-medium flex items-center gap-1">
                          <MonitorPlay className="w-3 h-3" />
                          {project.duration}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="pt-5 px-1">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="font-mono text-[9px] text-[#FF8F33] tracking-widest uppercase">
                            {project.client}
                          </span>
                          <span className="font-mono text-[9px] text-stone-500">
                            {project.year}
                          </span>
                        </div>
                        <h3 className="font-serif text-lg text-stone-100 font-semibold tracking-tight mb-2 group-hover:text-[#FF8F33] transition-colors line-clamp-1">
                          {project.title}
                        </h3>
                        <p className="font-sans text-xs text-stone-400 leading-relaxed mb-4 min-h-[50px] line-clamp-2">
                          {project.description}
                        </p>
                      </div>
                    </div>

                    {/* Tags & Action Link */}
                    <div className="w-full px-1">
                      {/* Project Category Tags */}
                      <div className="flex flex-wrap gap-1.5 mb-5">
                        {project.tags.slice(0, 2).map((tag) => (
                          <span
                            key={tag}
                            className="text-[9px] font-mono font-bold tracking-wider px-2.5 py-1 rounded-md bg-stone-900 border border-stone-850/60 text-stone-400 uppercase"
                          >
                            {tag}
                          </span>
                        ))}
                        {project.tags.length > 2 && (
                          <span className="text-[9px] font-mono font-semibold px-2 py-1 rounded-md bg-stone-900 border border-stone-850/20 text-stone-500">
                            +{project.tags.length - 2} More
                          </span>
                        )}
                      </div>

                      {/* Watch action button link */}
                      <button
                        id={`project-watch-link-${project.id}`}
                        onClick={() => onPlayProject(project.videoUrl, project.title)}
                        className="flex items-center gap-1.5 text-xs font-mono text-[#E5A463] hover:text-[#FF8F33] uppercase tracking-wider font-semibold group/link cursor-pointer"
                      >
                        Watch Case
                        <ArrowRight className="w-3.5 h-3.5 group-hover/link:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </ScrollReveal>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
