import { Project, AwardCaseStudy, ExperienceItem, EducationItem } from "./types";

export const HERO_DATA = {
  subTitle: "MOTION GRAPHIC DESIGNER & AI SPECIALIST — SUMIT SINGH",
  titlePart1: "Motion Graphics &",
  titlePart2: "Generative AI Video",
  description: "Hey there! I'm a passionate motion graphic designer with a flair for bringing ideas to life through captivating visuals and dynamic animations. I thrive on turning concepts into compelling stories that not only engage but also leave a lasting impression.",
  featuredIn: ["Motion Graphics", "AI Video", "Video Editing", "2D & 3D Animation", "Visual Storytelling", "Brand Content"],
  portraitUrl: "https://drive.google.com/thumbnail?id=1u6Cxx774AJ4c2m255vWhZoGOJ0p8WUO8&sz=w1000", // Direct premium thumbnail rendering
  resumeUrl: "https://drive.google.com/file/d/1-2ijUztkCCsoD9BBrBWg0E6nyCqr3nR2/view?usp=drive_link", // Custom resume file link
  // Alternatives: we can use a very sharp high quality model photo
  showreelTitle: "MY WORK",
  showreelCategory: "FEATURED SHOWREEL",
  showreelYear: "AI & Motion",
  projectsShippedCount: "300+",
  brandsCount: "Multiple Brands",
  // Video embed links (high quality creative commons/public motion design showreels)
  showreelVideoUrl: "https://assets.mixkit.co/videos/preview/mixkit-futuristic-subway-station-with-neon-lights-43283-large.mp4"
};

export const STATS_DATA = {
  heading: "Visual Excellence. Strategic Motion & Storytelling.",
  metrics: [
    {
      value: "5+",
      label: "Years shipping motion graphic design & AI animations"
    },
    {
      value: "100%",
      label: "Dedicated focus on delivering high-quality client results"
    },
    {
      value: "300+",
      label: "Deliverables across social, YouTube, and product visuals"
    },
    {
      value: "100%",
      label: "Remote-friendly with flexible global team synergy"
    }
  ]
};

export const AWARDS_DATA = {
  category: "ACHIEVEMENTS & RECOGNITION",
  heading: "Two-Time Student of the Month for Animation in MAAC.",
  description: "Awarded and recognized at the MAAC Institute (Maya Academy of Advanced Cinematics) in 2022 for digital media, multimedia design, and motion excellence.",
  caseStudies: [
    {
      id: "award-1",
      title: "MAAC Student of the Month",
      subtitle: "Animation & VFX Curriculum - 2022",
      description: "Twice awarded the prestigious Student of the Month honor at MAAC for creative storytelling, design aesthetic, and high-fidelity project execution.",
      category: "CORE ACHIEVEMENT"
    },
    {
      id: "award-2",
      title: "AI & Motion Workflow Integration",
      subtitle: "Advanced Production Pipelines - 2024",
      description: "Successfully integrated high-end generative AI tools (such as Higgsfield, Kling 3.0, Runway) into Premiere Pro, After Effects, and DaVinci pipelines.",
      category: "INNOVATION MILESTONE"
    }
  ]
};

export const PILLARS_DATA = {
  heading: "Four Pillars.",
  headingAccent: "One Cinematic Pipeline.",
  pillars: [
    {
      id: "01",
      title: "Motion Systems",
      description: "Reusable rigs and templates that convert briefs into delivery in days, not weeks."
    },
    {
      id: "02",
      title: "AI Video",
      description: "Generative previs, character beats, and finishing — built for premium, broadcast-grade output."
    },
    {
      id: "03",
      title: "CGI & 3D",
      description: "Photoreal product CGI and asset libraries owned by your brand, not the agency."
    },
    {
      id: "04",
      title: "Post & Marketing",
      description: "Editing, color, sound, and lifecycle cuts tuned for product, social, and ads."
    }
  ]
};

export const BRANDS_DATA = {
  heading: "Brand motion built for teams",
  headingAccent: "people already trust.",
  description: "A selection of in-house, agency, and direct-to-founder collaborations spanning SaaS, edtech, AI infrastructure, and consumer brands — most shipped under NDA. Logos shown represent past delivery scope.",
  brands: [
    "Toodi", "Skyfi", "Linear", "Groww", "Apollo", "Ditto",
    "Vector Labs", "Duolingo", "Studio Ghibli", "Adani", "Adobe", "Nvidia"
  ]
};

export const PROJECTS_DATA: Project[] = [
  // 1. Realistic Corporate Style Ai Videos
  {
    id: "proj-1",
    title: "Realistic AI Office Environment",
    description: "Dynamic corporate scene synthesis featuring realistic lighting, lifelike digital humans, and professional workspace design.",
    thumbnail: "https://img.youtube.com/vi/yPCqIwgXYx0/hqdefault.jpg",
    videoUrl: "https://youtu.be/yPCqIwgXYx0",
    duration: "0:52",
    category: "Realistic Corporate\nStyle Ai Videos",
    tags: ["REALISTIC AI", "CORPORATE SYNC", "WORKSPACE STUDY"],
    client: "Corporate AI",
    year: "2026"
  },
  {
    id: "proj-2",
    title: "Cinematic Executive Dialogue",
    description: "Advanced AI simulation depicting professional corporate discussions with photorealistic avatars and high-end cinematic pacing.",
    thumbnail: "https://img.youtube.com/vi/dPHUlKhCRSM/hqdefault.jpg",
    videoUrl: "https://youtu.be/dPHUlKhCRSM",
    duration: "0:45",
    category: "Realistic Corporate\nStyle Ai Videos",
    tags: ["EXECUTIVE AVATARS", "CINEMATIC PACE"],
    client: "NextGen Enterprise",
    year: "2026"
  },
  {
    id: "proj-3",
    title: "Corporate Hub Integration",
    description: "Hyper-realistic virtual environment detailing global corporate logistics and network hubs in real-time.",
    thumbnail: "https://img.youtube.com/vi/90PNdgGWnUM/hqdefault.jpg",
    videoUrl: "https://youtu.be/90PNdgGWnUM",
    duration: "0:40",
    category: "Realistic Corporate\nStyle Ai Videos",
    tags: ["LOGISTICS AI", "VIRTUAL HUB"],
    client: "Global Hub",
    year: "2026"
  },
  {
    id: "proj-4",
    title: "Strategic Boardroom Pre-Vis",
    description: "Innovative AI-driven commercial previsualization demonstrating executive decisions and modern architectural design.",
    thumbnail: "https://img.youtube.com/vi/SWYahaAiuc8/hqdefault.jpg",
    videoUrl: "https://youtu.be/SWYahaAiuc8",
    duration: "0:45",
    category: "Realistic Corporate\nStyle Ai Videos",
    tags: ["BOARDROOM AI", "PREVIS STUDY"],
    client: "Delta Group",
    year: "2025"
  },
  {
    id: "proj-5",
    title: "Premium Workspace Motion",
    description: "A high-impact realistic AI rendering showcasing futuristic enterprise workspace layouts and smart office setups.",
    thumbnail: "https://img.youtube.com/vi/3Z6T1YolxWs/hqdefault.jpg",
    videoUrl: "https://youtu.be/3Z6T1YolxWs",
    duration: "0:30",
    category: "Realistic Corporate\nStyle Ai Videos",
    tags: ["SMART OFFICE", "FUTURE WORKSPACE"],
    client: "Apex Spaces",
    year: "2026"
  },

  // 2. Animated Corporate Style Ai Videos
  {
    id: "proj-6",
    title: "SaaS Interface Walkthrough",
    description: "Stylized corporate interface presentation showing animated platform tutorials, data pipelines, and sleek UI flows.",
    thumbnail: "https://img.youtube.com/vi/Gw8TqnlcZiQ/hqdefault.jpg",
    videoUrl: "https://youtu.be/Gw8TqnlcZiQ",
    duration: "0:50",
    category: "Animated Corporate\nStyle Ai Videos",
    tags: ["ANIMATED UI", "SAAS MOTION"],
    client: "Linear SaaS",
    year: "2026"
  },
  {
    id: "proj-7",
    title: "Fintech Brand Core",
    description: "Energetic animated brand identity featuring sleek chart loops, micro-interactions, and financial growth pathways.",
    thumbnail: "https://img.youtube.com/vi/aoKSWOqe6RA/hqdefault.jpg",
    videoUrl: "https://youtu.be/aoKSWOqe6RA",
    duration: "1:00",
    category: "Animated Corporate\nStyle Ai Videos",
    tags: ["FINTECH DESIGN", "ANIMATED LOOPS"],
    client: "Groww Fin",
    year: "2026"
  },
  {
    id: "proj-8",
    title: "Modern Educational Promo",
    description: "Educational video style blending cute characters, bold typography layouts, and interactive UI visualizers.",
    thumbnail: "https://img.youtube.com/vi/ZS5_wTSMLQM/hqdefault.jpg",
    videoUrl: "https://youtu.be/ZS5_wTSMLQM",
    duration: "0:45",
    category: "Animated Corporate\nStyle Ai Videos",
    tags: ["EDTECH PROMO", "CHARACTER ANIMATION"],
    client: "Duolingo Inc",
    year: "2025"
  },

  // 3. Talking heads style
  {
    id: "proj-9",
    title: "AI Video Pipelines Explained",
    description: "Highly engaging talking head breakdown detailing state-of-the-art AI render rigs and automated workflows.",
    thumbnail: "https://img.youtube.com/vi/BGs7h0eh_Co/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/BGs7h0eh_Co?feature=share",
    duration: "0:59",
    category: "Talking heads style",
    tags: ["AI VIDEO", "TUTORIAL SHORT"],
    client: "Self-Published",
    year: "2026"
  },
  {
    id: "proj-10",
    title: "Scaling Motion Systems",
    description: "Interactive design guide showing how startup teams can deploy kinetic templates to scale content velocity.",
    thumbnail: "https://img.youtube.com/vi/kukJQfpOgeQ/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/kukJQfpOgeQ?feature=share",
    duration: "0:45",
    category: "Talking heads style",
    tags: ["MOTION DESIGN", "BRAND TIPS"],
    client: "Self-Published",
    year: "2026"
  },
  {
    id: "proj-11",
    title: "Award-Winning Frameworks",
    description: "Behind-the-scenes breakdown of the exact previsualization pipelines that won double Telly Awards.",
    thumbnail: "https://img.youtube.com/vi/-XrHD1kNEFc/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/-XrHD1kNEFc?feature=share",
    duration: "0:58",
    category: "Talking heads style",
    tags: ["CREATIVE PROCESS", "BEHIND THE SCENES"],
    client: "Telly Academy",
    year: "2026"
  },

  // 4. Map Animation
  {
    id: "proj-12",
    title: "Geospatial Flight Simulation",
    description: "Immersive geospatial map path tracing featuring detailed 3D typography, route animations, and dynamic transitions.",
    thumbnail: "https://img.youtube.com/vi/UuExfbHpIhM/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/UuExfbHpIhM?feature=share",
    duration: "0:50",
    category: "Map Animation",
    tags: ["MAP ANIMATION", "3D ROUTE"],
    client: "Map Studio",
    year: "2026"
  },

  // 5. Long Form Videos
  {
    id: "proj-13",
    title: "Comprehensive Workflow Masterclass",
    description: "In-depth complete masterclass of modern AI-assisted editing pipelines, software layouts, and creative strategies.",
    thumbnail: "https://img.youtube.com/vi/h1MUH_JgFbY/hqdefault.jpg",
    videoUrl: "https://youtu.be/h1MUH_JgFbY",
    duration: "10:15",
    category: "Long Form Videos",
    tags: ["WORKFLOW GUIDE", "LONG FORM"],
    client: "Self-Published",
    year: "2026"
  },
  {
    id: "proj-14",
    title: "Strategic Industry Showcase",
    description: "Vast corporate documentary mapping out global scaling networks, future trends, and sustainable automation.",
    thumbnail: "https://img.youtube.com/vi/QD42w7jG8As/hqdefault.jpg",
    videoUrl: "https://youtu.be/QD42w7jG8As",
    duration: "8:30",
    category: "Long Form Videos",
    tags: ["DOCUMENTARY", "CORPORATE VISION"],
    client: "Adani Group",
    year: "2026"
  },

  // 6. Short Form Videos
  {
    id: "proj-15",
    title: "Micro-Content Retention Secrets",
    description: "A high-impact social short highlighting top layout frameworks and sound effects for viral retention.",
    thumbnail: "https://img.youtube.com/vi/QINVXht4zcA/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/QINVXht4zcA?feature=share",
    duration: "0:45",
    category: "Short Form Videos",
    tags: ["RETENTION TIPS", "VIRAL SHORT"],
    client: "Creator Hub",
    year: "2026"
  },
  {
    id: "proj-16",
    title: "High-Energy Kinetic Hook",
    description: "Fast-paced social media ad demonstrating hyper-dynamic kinetic typo integration and sound sync.",
    thumbnail: "https://img.youtube.com/vi/xTzXFMfCj3A/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/xTzXFMfCj3A?feature=share",
    duration: "0:30",
    category: "Short Form Videos",
    tags: ["KINETIC HOOK", "SOCIAL AD"],
    client: "Vibe Media",
    year: "2026"
  },
  {
    id: "proj-17",
    title: "Unlocking AI Workflows",
    description: "Sleek mobile tutorial focusing on prompt configurations and model selection for cinematic generation.",
    thumbnail: "https://img.youtube.com/vi/n21bPjyUJwE/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/n21bPjyUJwE?feature=share",
    duration: "0:55",
    category: "Short Form Videos",
    tags: ["CREATIVE AI", "TUTORIAL"],
    client: "Prompt Guide",
    year: "2026"
  },
  {
    id: "proj-18",
    title: "Next-Gen Mobile Teaser",
    description: "Supercharged vertical teaser featuring clean device mockups, smooth swipes, and visual pacing.",
    thumbnail: "https://img.youtube.com/vi/1YOCnO9M4Xw/hqdefault.jpg",
    videoUrl: "https://youtube.com/shorts/1YOCnO9M4Xw?feature=share",
    duration: "0:35",
    category: "Short Form Videos",
    tags: ["DEVICE TEASER", "MOBILE MOTION"],
    client: "Skyfi App",
    year: "2026"
  },

  // 7. UI Animation Videos
  {
    id: "proj-19",
    title: "SaaS Dashboard Interaction",
    description: "Ultra-smooth UI motion showing interactive control toggles, data visualizations, and transition pathways.",
    thumbnail: "https://img.youtube.com/vi/1rAVsM7sPcc/hqdefault.jpg",
    videoUrl: "https://youtu.be/1rAVsM7sPcc",
    duration: "1:10",
    category: "UI Animation Videos",
    tags: ["DASHBOARD MOTION", "UI INTERACTIVE"],
    client: "Apollo UI",
    year: "2026"
  },
  {
    id: "proj-20",
    title: "Mobile Workflow Automation",
    description: "Sleek walkthrough highlighting intuitive drag-and-drop mechanics, file syncs, and team views.",
    thumbnail: "https://img.youtube.com/vi/KL_fWcXu3FA/hqdefault.jpg",
    videoUrl: "https://youtu.be/KL_fWcXu3FA",
    duration: "0:45",
    category: "UI Animation Videos",
    tags: ["MOBILE UI", "AUTOMATION MOTION"],
    client: "Toodi Labs",
    year: "2026"
  }
];

export const EXPERIENCE_DATA: ExperienceItem[] = [
  {
    id: "exp-1",
    role: "Lead Motion Graphics Designer / AI Specialist",
    company: "Applause (Firewalker Apps)",
    period: "APRIL 2024 — CURRENT",
    type: "Lead Role",
    bullets: [
      "Produced captivating video content, edited and enhanced visuals, and collaborated closely on creative projects.",
      "Integrated AI-powered workflows leveraging Higgsfield, Kling 3.0, and Nano Banana Pro to maximize production speed.",
      "Maintained aesthetic standards across marketing campaigns, short-form content, and SaaS explainer videos."
    ]
  },
  {
    id: "exp-2",
    role: "Motion Graphics Designer",
    company: "Mandala Studios",
    period: "DEC 2022 — APRIL 2024",
    type: "Full-Time",
    bullets: [
      "Produced visually appealing motion design content for YouTube and various corporate social media campaigns.",
      "Elevated brand engagement through consistent visual styling, dynamic typography layout, and smooth animations.",
      "Coordinated with production teams and client stakeholders to deliver polished multimedia assets on tight schedules."
    ]
  },
  {
    id: "exp-3",
    role: "Motion Designer / Video Editor",
    company: "Freelance",
    period: "MARCH 2021 — DEC 2022",
    type: "Freelance",
    bullets: [
      "Generated diverse video and motion content for various global clients, enhancing online visibility and engagement.",
      "Handled end-to-end video editing, audio mixing, color correction, and kinetic text integration.",
      "Demonstrated great remote synergy, timezone flexibility, and rapid brief-to-delivery communication."
    ]
  }
];

export const SKILLS_DATA = {
  coreSkills: [
    "Motion Graphics",
    "AI Video Creation",
    "Video Editing",
    "2D & 3D Animation",
    "Visual Storytelling",
    "Brand & Social Content",
    "Short-form Content",
    "SaaS Explainer Videos"
  ],
  softwareProficiency: [
    "After Effects",
    "Premiere Pro",
    "DaVinci Resolve",
    "Illustrator",
    "Photoshop",
    "Blender",
    "Figma",
    "Rive",
    "Lottie",
    "Canva"
  ],
  aiCreativeTools: [
    "Higgsfield",
    "NanoBanana Pro",
    "Kling 3.0",
    "ChatGPT",
    "Midjourney",
    "Topaz",
    "Runway",
    "Adobe Firefly",
    "Upscayl",
    "DALL-E"
  ]
};

export const EDUCATION_DATA: EducationItem[] = [
  {
    id: "edu-1",
    institution: "MAAC",
    degree: "Diploma in Fine Arts in Digital Media and Multimedia Design",
    period: "2020 — 2022"
  },
  {
    id: "edu-2",
    institution: "Patliputra University",
    degree: "Bachelor of Arts in History Honours",
    period: "2021 — 2024"
  }
];
